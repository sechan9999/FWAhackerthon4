"""
다국어 지원 모듈 (Internationalization)
========================================
한국어/영어 전환을 지원하는 중앙 번역 시스템.
모든 UI 텍스트와 분석 결과 메시지를 관리.

Usage:
    from engine.i18n import t, set_language, get_language
    set_language("ko")
    print(t("nav.realtime_scan"))  # "🔍 AI 실시간 분석"
"""
from typing import Dict

_current_lang = "ko"

TRANSLATIONS: Dict[str, Dict[str, str]] = {
    # ========== Navigation ==========
    "nav.realtime_scan": {
        "ko": "🔍 AI 실시간 분석",
        "en": "🔍 AI Real-time Scan"
    },
    "nav.batch_pattern": {
        "ko": "📊 배치 검증 & 패턴",
        "en": "📊 Batch Validate & Pattern"
    },
    "nav.investigator": {
        "ko": "🕵️ AI 수사관 Chat",
        "en": "🕵️ AI Investigator Chat"
    },
    "nav.provider_network": {
        "ko": "🕸️ Provider 네트워크",
        "en": "🕸️ Provider Network"
    },
    "nav.temporal": {
        "ko": "📅 시계열 이상 탐지",
        "en": "📅 Temporal Anomaly"
    },
    "nav.rule_dict": {
        "ko": "📖 규칙 사전",
        "en": "📖 Rule Dictionary"
    },
    "nav.dashboard": {
        "ko": "📈 분석 대시보드",
        "en": "📈 Analytics Dashboard"
    },
    "nav.settings": {
        "ko": "⚙️ 설정 & 알림",
        "en": "⚙️ Settings & Alerts"
    },

    # ========== Common ==========
    "common.analyze": {
        "ko": "🚀 AI 분석 시작",
        "en": "🚀 Start AI Analysis"
    },
    "common.total_claims": {
        "ko": "총 청구",
        "en": "Total Claims"
    },
    "common.flagged": {
        "ko": "🚩 플래그",
        "en": "🚩 Flagged"
    },
    "common.pass_rate": {
        "ko": "통과율",
        "en": "Pass Rate"
    },
    "common.risk_amount": {
        "ko": "위험 금액",
        "en": "At-Risk Amount"
    },
    "common.total_amount": {
        "ko": "총 청구액",
        "en": "Total Amount"
    },
    "common.download_csv": {
        "ko": "📥 CSV 다운로드",
        "en": "📥 Download CSV"
    },
    "common.loading": {
        "ko": "분석 중...",
        "en": "Analyzing..."
    },
    "common.severity": {
        "ko": "심각도",
        "en": "Severity"
    },

    # ========== Real-time Scan ==========
    "scan.title": {
        "ko": "🔍 실시간 청구 AI 분석",
        "en": "🔍 Real-time Claim AI Analysis"
    },
    "scan.subtitle": {
        "ko": "룰엔진 검증 + OpenAI GPT 심층 분석",
        "en": "Rule Engine + OpenAI GPT Deep Analysis"
    },
    "scan.scenario_tab": {
        "ko": "📋 시나리오 선택",
        "en": "📋 Select Scenario"
    },
    "scan.manual_tab": {
        "ko": "✏️ 직접 입력",
        "en": "✏️ Manual Input"
    },
    "scan.ai_result": {
        "ko": "🤖 AI 분석 결과",
        "en": "🤖 AI Analysis Result"
    },
    "scan.rule_detail": {
        "ko": "📋 룰엔진 검증 상세",
        "en": "📋 Rule Engine Details"
    },
    "scan.ai_summary": {
        "ko": "📝 AI 분석 요약",
        "en": "📝 AI Analysis Summary"
    },
    "scan.medical_reason": {
        "ko": "🏥 의학적 판단 근거",
        "en": "🏥 Medical Reasoning"
    },
    "scan.claim_data": {
        "ko": "📋 청구 데이터",
        "en": "📋 Claim Data"
    },

    # ========== Batch ==========
    "batch.title": {
        "ko": "📊 배치 검증 & AI 패턴 탐지",
        "en": "📊 Batch Validation & AI Pattern Detection"
    },
    "batch.generate": {
        "ko": "🔬 데이터 생성 & 검증",
        "en": "🔬 Generate & Validate"
    },
    "batch.records": {
        "ko": "레코드 수",
        "en": "Record Count"
    },
    "batch.anomaly_rate": {
        "ko": "이상 비율 (%)",
        "en": "Anomaly Rate (%)"
    },
    "batch.pattern_run": {
        "ko": "🧠 AI 패턴 분석 실행",
        "en": "🧠 Run AI Pattern Analysis"
    },
    "batch.pattern_title": {
        "ko": "🤖 AI 패턴 탐지",
        "en": "🤖 AI Pattern Detection"
    },
    "batch.patterns_found": {
        "ko": "🔎 탐지된 패턴",
        "en": "🔎 Detected Patterns"
    },
    "batch.assessment": {
        "ko": "📋 종합 평가",
        "en": "📋 Overall Assessment"
    },
    "batch.priority": {
        "ko": "🎯 우선 조치",
        "en": "🎯 Priority Actions"
    },

    # ========== Investigator Chat ==========
    "chat.title": {
        "ko": "🕵️ AI 수사관 (Investigator Chat)",
        "en": "🕵️ AI Investigator Chat"
    },
    "chat.subtitle": {
        "ko": "자연어로 청구 데이터를 조사하세요",
        "en": "Investigate claims data in natural language"
    },
    "chat.placeholder": {
        "ko": "질문을 입력하세요...",
        "en": "Type your question..."
    },
    "chat.clear": {
        "ko": "🗑️ 대화 초기화",
        "en": "🗑️ Clear Chat"
    },
    "chat.example_title": {
        "ko": "💬 예시 질문",
        "en": "💬 Example Questions"
    },
    "chat.examples": {
        "ko": [
            "플래그된 청구 중 가장 위험한 패턴은?",
            "GLP-1 오남용 의심 건을 분석해줘",
            "HCC Upcoding 의심 Provider를 찾아줘",
            "전체 위험 금액과 우선 조치를 요약해줘",
        ],
        "en": [
            "What are the most dangerous patterns in flagged claims?",
            "Analyze suspected GLP-1 misuse cases",
            "Find providers suspected of HCC Upcoding",
            "Summarize total at-risk amount and priority actions",
        ]
    },

    # ========== Provider Network ==========
    "network.title": {
        "ko": "🕸️ Provider 네트워크 분석",
        "en": "🕸️ Provider Network Analysis"
    },
    "network.subtitle": {
        "ko": "의료기관 간 연결 관계와 이상 패턴을 시각화합니다",
        "en": "Visualize connections and anomaly patterns between providers"
    },
    "network.run": {
        "ko": "🔬 네트워크 분석 실행",
        "en": "🔬 Run Network Analysis"
    },
    "network.metrics": {
        "ko": "📊 네트워크 지표",
        "en": "📊 Network Metrics"
    },
    "network.suspicious": {
        "ko": "🚨 의심 Provider 클러스터",
        "en": "🚨 Suspicious Provider Clusters"
    },
    "network.referral": {
        "ko": "환자 공유 패턴",
        "en": "Patient Sharing Patterns"
    },

    # ========== Temporal ==========
    "temporal.title": {
        "ko": "📅 시계열 이상 탐지",
        "en": "📅 Temporal Anomaly Detection"
    },
    "temporal.subtitle": {
        "ko": "시간 흐름에 따른 청구 패턴 변화와 이상 징후를 탐지합니다",
        "en": "Detect anomalies in claim patterns over time"
    },
    "temporal.run": {
        "ko": "📅 시계열 분석 실행",
        "en": "📅 Run Temporal Analysis"
    },
    "temporal.monthly_trend": {
        "ko": "📈 월별 청구 추이",
        "en": "📈 Monthly Claim Trends"
    },
    "temporal.spike_alert": {
        "ko": "🚨 이상 급증 탐지",
        "en": "🚨 Spike Alerts"
    },
    "temporal.eoy_upcoding": {
        "ko": "📅 연말 업코딩 패턴",
        "en": "📅 End-of-Year Upcoding Pattern"
    },

    # ========== Alerts ==========
    "alerts.title": {
        "ko": "⚙️ 설정 & 실시간 알림",
        "en": "⚙️ Settings & Real-time Alerts"
    },
    "alerts.slack_section": {
        "ko": "💬 Slack 알림 설정",
        "en": "💬 Slack Alert Settings"
    },
    "alerts.teams_section": {
        "ko": "📎 Microsoft Teams 알림 설정",
        "en": "📎 Microsoft Teams Alert Settings"
    },
    "alerts.webhook_url": {
        "ko": "Webhook URL",
        "en": "Webhook URL"
    },
    "alerts.test_send": {
        "ko": "📤 테스트 알림 전송",
        "en": "📤 Send Test Alert"
    },
    "alerts.send_success": {
        "ko": "✅ 알림 전송 성공!",
        "en": "✅ Alert sent successfully!"
    },
    "alerts.send_fail": {
        "ko": "❌ 알림 전송 실패",
        "en": "❌ Alert send failed"
    },
    "alerts.sagemaker_section": {
        "ko": "☁️ AWS SageMaker 설정",
        "en": "☁️ AWS SageMaker Settings"
    },
    "alerts.lang_section": {
        "ko": "🌐 언어 설정",
        "en": "🌐 Language Settings"
    },

    # ========== Dashboard ==========
    "dashboard.title": {
        "ko": "📈 분석 대시보드",
        "en": "📈 Analytics Dashboard"
    },
    "dashboard.severity_dist": {
        "ko": "심각도 분포",
        "en": "Severity Distribution"
    },
    "dashboard.anomaly_dist": {
        "ko": "이상 유형 분포",
        "en": "Anomaly Type Distribution"
    },
    "dashboard.provider_rank": {
        "ko": "🏥 Provider별 위반 현황 (Top 10)",
        "en": "🏥 Provider Violation Ranking (Top 10)"
    },
    "dashboard.generate_sample": {
        "ko": "🔬 샘플 500건 빠르게 생성",
        "en": "🔬 Quick Generate 500 Samples"
    },
    "dashboard.no_data": {
        "ko": "💡 '배치 검증 & 패턴' 탭에서 데이터를 생성해주세요.",
        "en": "💡 Please generate data in 'Batch Validate & Pattern' tab."
    },

    # ========== Sidebar ==========
    "sidebar.title": {
        "ko": "🛡️ FWA Detection",
        "en": "🛡️ FWA Detection"
    },
    "sidebar.subtitle": {
        "ko": "AI 기반 부정청구 탐지 시스템",
        "en": "AI-Powered Fraud Detection System"
    },
    "sidebar.openai_settings": {
        "ko": "⚙️ OpenAI 설정",
        "en": "⚙️ OpenAI Settings"
    },
    "sidebar.system_status": {
        "ko": "🔌 시스템 상태",
        "en": "🔌 System Status"
    },
    "sidebar.api_connected": {
        "ko": "✅ OpenAI 연결됨",
        "en": "✅ OpenAI Connected"
    },
    "sidebar.api_missing": {
        "ko": "⚠️ API key 미설정 (룰 기반 모드)",
        "en": "⚠️ API key missing (Rule-based mode)"
    },
    "sidebar.langgraph_active": {
        "ko": "✅ LangGraph 활성",
        "en": "✅ LangGraph Active"
    },
    "sidebar.langgraph_seq": {
        "ko": "⚠️ LangGraph 미설치 (순차 모드)",
        "en": "⚠️ LangGraph not installed (Sequential mode)"
    },
}


def set_language(lang: str):
    """언어 설정 (ko / en)"""
    global _current_lang
    if lang in ("ko", "en"):
        _current_lang = lang


def get_language() -> str:
    """현재 언어 반환"""
    return _current_lang


def t(key: str, **kwargs) -> str:
    """
    번역 키로 현재 언어의 텍스트 반환.
    
    Usage:
        t("nav.realtime_scan")
        t("common.total_claims")
    """
    entry = TRANSLATIONS.get(key)
    if entry is None:
        return key
    
    value = entry.get(_current_lang, entry.get("ko", key))
    
    # 리스트인 경우 그대로 반환 (예: chat.examples)
    if isinstance(value, list):
        return value
    
    # 포맷팅 지원
    if kwargs:
        try:
            return value.format(**kwargs)
        except (KeyError, IndexError):
            return value
    
    return value


def get_all_languages():
    """지원 언어 목록"""
    return {"ko": "한국어", "en": "English"}
