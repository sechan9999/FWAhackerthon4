"""
실시간 알림 모듈 (Slack / Microsoft Teams)
============================================
FWA 탐지 결과를 Slack 및 Teams Webhook으로 실시간 전송.

지원 채널:
  - Slack (Incoming Webhook)
  - Microsoft Teams (Incoming Webhook)

Usage:
    mgr = AlertManager(slack_url="https://hooks.slack.com/...", teams_url="https://...")
    mgr.send_fwa_alert(claim_id="CLM-001", risk="HIGH", action="BLOCK", score=85.0)
"""
import os
import json
import logging
from typing import Dict, List, Optional
from datetime import datetime

logger = logging.getLogger(__name__)

try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False
    logger.warning("requests not installed. Run: pip install requests")


class AlertManager:
    """
    FWA 알림 매니저.
    
    Slack 및 Teams Webhook URL을 설정하면,
    FWA 탐지 결과를 실시간으로 전송.
    """
    
    def __init__(
        self,
        slack_url: Optional[str] = None,
        teams_url: Optional[str] = None,
        min_severity: str = "WARNING"
    ):
        """
        Args:
            slack_url: Slack Incoming Webhook URL
            teams_url: Teams Incoming Webhook URL
            min_severity: 최소 알림 심각도 (CRITICAL / WARNING / INFO)
        """
        self.slack_url = slack_url or os.environ.get("SLACK_WEBHOOK_URL")
        self.teams_url = teams_url or os.environ.get("TEAMS_WEBHOOK_URL")
        self.min_severity = min_severity
        self._severity_order = {"CRITICAL": 3, "WARNING": 2, "INFO": 1}
    
    @property
    def slack_configured(self) -> bool:
        return bool(self.slack_url)
    
    @property
    def teams_configured(self) -> bool:
        return bool(self.teams_url)
    
    @property
    def any_configured(self) -> bool:
        return self.slack_configured or self.teams_configured
    
    def send_fwa_alert(
        self,
        claim_id: str,
        risk_level: str,
        recommended_action: str,
        risk_score: float,
        summary: str = "",
        provider_id: str = "",
        anomaly_types: List[str] = None
    ) -> List[str]:
        """
        FWA 탐지 알림 전송.
        
        Returns:
            전송 성공한 채널 리스트 ["slack", "teams"]
        """
        if not self._should_alert(risk_level):
            return []
        
        sent = []
        
        # Slack 전송
        if self.slack_configured:
            payload = self._build_slack_payload(
                claim_id, risk_level, recommended_action, risk_score,
                summary, provider_id, anomaly_types
            )
            if self._send_webhook(self.slack_url, payload):
                sent.append("slack")
        
        # Teams 전송
        if self.teams_configured:
            payload = self._build_teams_payload(
                claim_id, risk_level, recommended_action, risk_score,
                summary, provider_id, anomaly_types
            )
            if self._send_webhook(self.teams_url, payload):
                sent.append("teams")
        
        return sent
    
    def send_batch_summary(
        self,
        total_claims: int,
        flagged_claims: int,
        critical_count: int,
        total_risk_amount: float,
        top_anomalies: List[str] = None
    ) -> List[str]:
        """배치 검증 요약 알림 전송"""
        sent = []
        
        flag_rate = flagged_claims / total_claims if total_claims > 0 else 0
        
        # Slack
        if self.slack_configured:
            payload = {
                "blocks": [
                    {
                        "type": "header",
                        "text": {"type": "plain_text", "text": "📊 FWA Batch Validation Complete"}
                    },
                    {
                        "type": "section",
                        "fields": [
                            {"type": "mrkdwn", "text": f"*Total Claims:*\n{total_claims:,}"},
                            {"type": "mrkdwn", "text": f"*Flagged:*\n{flagged_claims:,} ({flag_rate:.1%})"},
                            {"type": "mrkdwn", "text": f"*Critical:*\n{critical_count}"},
                            {"type": "mrkdwn", "text": f"*Risk Amount:*\n${total_risk_amount:,.2f}"},
                        ]
                    },
                ]
            }
            if top_anomalies:
                payload["blocks"].append({
                    "type": "section",
                    "text": {"type": "mrkdwn",
                             "text": f"*Top Anomalies:* {', '.join(top_anomalies[:5])}"}
                })
            payload["blocks"].append({
                "type": "context",
                "elements": [{"type": "mrkdwn",
                               "text": f"⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"}]
            })
            if self._send_webhook(self.slack_url, payload):
                sent.append("slack")
        
        # Teams
        if self.teams_configured:
            facts = [
                {"name": "Total Claims", "value": f"{total_claims:,}"},
                {"name": "Flagged", "value": f"{flagged_claims:,} ({flag_rate:.1%})"},
                {"name": "Critical", "value": str(critical_count)},
                {"name": "Risk Amount", "value": f"${total_risk_amount:,.2f}"},
            ]
            if top_anomalies:
                facts.append({"name": "Top Anomalies", "value": ", ".join(top_anomalies[:5])})
            
            payload = self._teams_card("📊 FWA Batch Validation Complete", facts, "0076D7")
            if self._send_webhook(self.teams_url, payload):
                sent.append("teams")
        
        return sent
    
    def send_all(self, message: str) -> List[str]:
        """일반 메시지 전송 (모든 채널)"""
        sent = []
        
        if self.slack_configured:
            if self._send_webhook(self.slack_url, {"text": message}):
                sent.append("slack")
        
        if self.teams_configured:
            payload = {"text": message}
            if self._send_webhook(self.teams_url, payload):
                sent.append("teams")
        
        return sent
    
    def send_test(self) -> Dict[str, bool]:
        """테스트 알림 전송 — 연결 확인용"""
        results = {}
        
        test_msg = (
            "🧪 *FWA Detection Test Alert*\n"
            f"This is a test message sent at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
            "If you see this, alerts are working correctly! ✅"
        )
        
        if self.slack_configured:
            results["slack"] = self._send_webhook(self.slack_url, {"text": test_msg})
        else:
            results["slack"] = False
        
        if self.teams_configured:
            payload = self._teams_card(
                "🧪 FWA Detection Test Alert",
                [{"name": "Status", "value": "Test Passed ✅"},
                 {"name": "Time", "value": datetime.now().strftime('%Y-%m-%d %H:%M:%S')}],
                "00FF00"
            )
            results["teams"] = self._send_webhook(self.teams_url, payload)
        else:
            results["teams"] = False
        
        return results
    
    # ==================== Private Methods ====================
    
    def _should_alert(self, risk_level: str) -> bool:
        """심각도 필터"""
        level = self._severity_order.get(risk_level.upper(), 0)
        threshold = self._severity_order.get(self.min_severity.upper(), 2)
        return level >= threshold
    
    def _build_slack_payload(
        self, claim_id, risk_level, action, score, summary, provider_id, anomaly_types
    ) -> Dict:
        """Slack Block Kit 메시지 구성"""
        color = {"HIGH": "#FF0000", "MEDIUM": "#FFA500", "LOW": "#FFFF00"}.get(risk_level, "#808080")
        emoji = {"HIGH": "🔴", "MEDIUM": "🟡", "LOW": "🟢"}.get(risk_level, "⚪")
        action_emoji = {"BLOCK": "🚫", "REVIEW": "👁️", "MONITOR": "📡", "APPROVE": "✅"}.get(action, "❓")
        
        fields = [
            {"type": "mrkdwn", "text": f"*Claim ID:*\n`{claim_id}`"},
            {"type": "mrkdwn", "text": f"*Risk Level:*\n{emoji} {risk_level}"},
            {"type": "mrkdwn", "text": f"*Score:*\n{score:.1f}/100"},
            {"type": "mrkdwn", "text": f"*Action:*\n{action_emoji} {action}"},
        ]
        
        if provider_id:
            fields.append({"type": "mrkdwn", "text": f"*Provider:*\n`{provider_id}`"})
        
        blocks = [
            {"type": "header", "text": {"type": "plain_text", "text": f"🚨 FWA Alert — {risk_level}"}},
            {"type": "section", "fields": fields},
        ]
        
        if summary:
            blocks.append({"type": "section", "text": {"type": "mrkdwn", "text": f"*Summary:*\n{summary[:500]}"}})
        
        if anomaly_types:
            tags = " | ".join(f"`{t}`" for t in anomaly_types[:5])
            blocks.append({"type": "section", "text": {"type": "mrkdwn", "text": f"*Anomalies:* {tags}"}})
        
        blocks.append({
            "type": "context",
            "elements": [{"type": "mrkdwn",
                           "text": f"⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | FWA Detection System"}]
        })
        
        return {"blocks": blocks}
    
    def _build_teams_payload(
        self, claim_id, risk_level, action, score, summary, provider_id, anomaly_types
    ) -> Dict:
        """Teams Adaptive Card 메시지 구성"""
        color = {"HIGH": "FF0000", "MEDIUM": "FFA500", "LOW": "00FF00"}.get(risk_level, "808080")
        
        facts = [
            {"name": "Claim ID", "value": claim_id},
            {"name": "Risk Level", "value": risk_level},
            {"name": "Score", "value": f"{score:.1f}/100"},
            {"name": "Action", "value": action},
        ]
        
        if provider_id:
            facts.append({"name": "Provider", "value": provider_id})
        if summary:
            facts.append({"name": "Summary", "value": summary[:300]})
        if anomaly_types:
            facts.append({"name": "Anomalies", "value": ", ".join(anomaly_types[:5])})
        
        return self._teams_card(f"🚨 FWA Alert — {risk_level}", facts, color)
    
    def _teams_card(self, title: str, facts: List[Dict], color: str) -> Dict:
        """Teams MessageCard 구성"""
        return {
            "@type": "MessageCard",
            "@context": "http://schema.org/extensions",
            "themeColor": color,
            "summary": title,
            "sections": [{
                "activityTitle": title,
                "activitySubtitle": datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                "facts": facts,
                "markdown": True
            }]
        }
    
    def _send_webhook(self, url: str, payload: Dict) -> bool:
        """Webhook 전송"""
        if not REQUESTS_AVAILABLE:
            logger.warning("requests not installed — cannot send webhook")
            return False
        
        if not url:
            return False
        
        try:
            response = requests.post(
                url,
                json=payload,
                headers={"Content-Type": "application/json"},
                timeout=10
            )
            if response.status_code in (200, 204):
                logger.info(f"Alert sent to {url[:50]}...")
                return True
            else:
                logger.warning(f"Alert failed: {response.status_code} {response.text[:200]}")
                return False
        except Exception as e:
            logger.error(f"Webhook error: {e}")
            return False
