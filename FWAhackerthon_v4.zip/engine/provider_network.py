"""
Provider 네트워크 분석 모듈
=============================
의료기관 간 환자 공유 패턴을 그래프로 분석하여
킥백(kickback), 환자 돌려막기(patient steering) 등 이상 패턴 탐지.

NetworkX 기반 그래프 분석 + 커뮤니티 탐지.
"""
import pandas as pd
import numpy as np
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass, field, asdict
from collections import defaultdict
import logging
import json

logger = logging.getLogger(__name__)

try:
    import networkx as nx
    NETWORKX_AVAILABLE = True
except ImportError:
    NETWORKX_AVAILABLE = False
    logger.warning("networkx not installed. Run: pip install networkx")


@dataclass
class ProviderProfile:
    """Provider 프로파일"""
    provider_id: str
    total_claims: int = 0
    flagged_claims: int = 0
    flag_rate: float = 0.0
    total_amount: float = 0.0
    flagged_amount: float = 0.0
    unique_patients: int = 0
    top_icd_codes: List[str] = field(default_factory=list)
    top_anomaly_types: List[str] = field(default_factory=list)
    risk_score: float = 0.0
    connected_providers: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict:
        return asdict(self)


@dataclass 
class NetworkAnalysisResult:
    """네트워크 분석 결과"""
    total_providers: int = 0
    total_edges: int = 0
    avg_degree: float = 0.0
    density: float = 0.0
    clusters: List[Dict] = field(default_factory=list)
    suspicious_providers: List[Dict] = field(default_factory=list)
    referral_anomalies: List[Dict] = field(default_factory=list)
    hub_providers: List[Dict] = field(default_factory=list)
    
    def to_dict(self) -> Dict:
        return asdict(self)


class ProviderNetworkAnalyzer:
    """
    Provider 네트워크 분석기.
    
    환자를 공유하는 Provider 간의 관계를 그래프로 구성하고,
    이상 패턴(킥백, 환자 돌려막기 등)을 탐지.
    
    Usage:
        analyzer = ProviderNetworkAnalyzer()
        result = analyzer.analyze(df)  # validated DataFrame
    """
    
    def __init__(self, shared_patient_threshold: int = 2):
        """
        Args:
            shared_patient_threshold: 연결로 간주할 최소 공유 환자 수
        """
        self.threshold = shared_patient_threshold
    
    def analyze(self, df: pd.DataFrame) -> NetworkAnalysisResult:
        """
        전체 네트워크 분석 실행.
        
        Args:
            df: validated DataFrame (provider_id, patient_id, is_flagged 등 필요)
        Returns:
            NetworkAnalysisResult
        """
        result = NetworkAnalysisResult()
        
        if "provider_id" not in df.columns or "patient_id" not in df.columns:
            logger.warning("Required columns (provider_id, patient_id) missing")
            return result
        
        # 1. Provider 프로파일 생성
        profiles = self._build_profiles(df)
        
        # 2. 그래프 구성
        G = self._build_graph(df)
        
        if G is None:
            # NetworkX 미설치 시 프로파일 기반 분석만
            result.total_providers = len(profiles)
            result.suspicious_providers = self._find_suspicious_by_stats(profiles)
            return result
        
        # 3. 네트워크 지표 계산
        result.total_providers = G.number_of_nodes()
        result.total_edges = G.number_of_edges()
        result.avg_degree = sum(dict(G.degree()).values()) / max(G.number_of_nodes(), 1)
        result.density = nx.density(G)
        
        # 4. 커뮤니티 탐지 (클러스터)
        result.clusters = self._detect_communities(G, profiles)
        
        # 5. 의심 Provider 탐지
        result.suspicious_providers = self._find_suspicious(G, profiles)
        
        # 6. Hub Provider (비정상적 연결 수)
        result.hub_providers = self._find_hubs(G, profiles)
        
        # 7. 이상 의뢰 패턴
        result.referral_anomalies = self._find_referral_anomalies(G, df, profiles)
        
        return result
    
    def _build_profiles(self, df: pd.DataFrame) -> Dict[str, ProviderProfile]:
        """Provider별 프로파일 생성"""
        profiles = {}
        
        for prov_id, group in df.groupby("provider_id"):
            flagged = group[group.get("is_flagged", False)] if "is_flagged" in group.columns else pd.DataFrame()
            
            top_icds = []
            if "icd_codes" in group.columns:
                all_icds = group["icd_codes"].dropna().str.split(",").explode().str.strip()
                top_icds = all_icds.value_counts().head(3).index.tolist()
            
            top_anomalies = []
            if "anomaly_type" in group.columns:
                top_anomalies = group["anomaly_type"].value_counts().head(3).index.tolist()
            
            total_claims = len(group)
            flagged_claims = len(flagged)
            flag_rate = flagged_claims / total_claims if total_claims > 0 else 0
            
            # 리스크 스코어 계산
            risk = flag_rate * 50  # flag rate 기여
            if "claim_amount" in group.columns and len(flagged) > 0:
                risk += min(flagged["claim_amount"].sum() / 10000, 30)  # 금액 기여 (최대 30)
            if "max_severity" in group.columns:
                critical_pct = (group["max_severity"] == "CRITICAL").sum() / total_claims
                risk += critical_pct * 20
            
            profiles[prov_id] = ProviderProfile(
                provider_id=prov_id,
                total_claims=total_claims,
                flagged_claims=flagged_claims,
                flag_rate=round(flag_rate, 3),
                total_amount=round(group["claim_amount"].sum(), 2) if "claim_amount" in group.columns else 0,
                flagged_amount=round(flagged["claim_amount"].sum(), 2) if "claim_amount" in flagged.columns and len(flagged) > 0 else 0,
                unique_patients=group["patient_id"].nunique(),
                top_icd_codes=top_icds,
                top_anomaly_types=top_anomalies,
                risk_score=round(min(risk, 100), 1)
            )
        
        return profiles
    
    def _build_graph(self, df: pd.DataFrame) -> Optional['nx.Graph']:
        """Provider-Patient 관계에서 Provider 네트워크 구성"""
        if not NETWORKX_AVAILABLE:
            return None
        
        G = nx.Graph()
        
        # Patient → Provider 매핑
        patient_providers = defaultdict(set)
        for _, row in df.iterrows():
            patient_providers[row["patient_id"]].add(row["provider_id"])
        
        # 공유 환자를 통한 Provider 간 연결
        provider_pairs = defaultdict(int)
        for patient_id, providers in patient_providers.items():
            providers = list(providers)
            for i in range(len(providers)):
                for j in range(i + 1, len(providers)):
                    pair = tuple(sorted([providers[i], providers[j]]))
                    provider_pairs[pair] += 1
        
        # 임계값 이상만 엣지 추가
        for (p1, p2), shared_count in provider_pairs.items():
            if shared_count >= self.threshold:
                G.add_edge(p1, p2, weight=shared_count, shared_patients=shared_count)
        
        # 고립 노드도 추가
        for prov_id in df["provider_id"].unique():
            if prov_id not in G:
                G.add_node(prov_id)
        
        return G
    
    def _detect_communities(self, G: 'nx.Graph', profiles: Dict) -> List[Dict]:
        """커뮤니티(클러스터) 탐지"""
        clusters = []
        
        try:
            communities = nx.community.greedy_modularity_communities(G)
            
            for i, comm in enumerate(communities):
                members = list(comm)
                if len(members) < 2:
                    continue
                
                avg_risk = np.mean([profiles[m].risk_score for m in members if m in profiles])
                total_flagged = sum(profiles[m].flagged_claims for m in members if m in profiles)
                
                clusters.append({
                    "cluster_id": i,
                    "members": members[:20],  # 상위 20개만
                    "size": len(members),
                    "avg_risk_score": round(avg_risk, 1),
                    "total_flagged_claims": total_flagged,
                    "risk_level": "HIGH" if avg_risk > 50 else "MEDIUM" if avg_risk > 25 else "LOW"
                })
            
            clusters.sort(key=lambda x: x["avg_risk_score"], reverse=True)
        except Exception as e:
            logger.warning(f"Community detection failed: {e}")
        
        return clusters[:10]
    
    def _find_suspicious(self, G: 'nx.Graph', profiles: Dict) -> List[Dict]:
        """의심 Provider 탐지 — 높은 리스크 + 높은 연결성"""
        suspicious = []
        
        betweenness = nx.betweenness_centrality(G) if G.number_of_edges() > 0 else {}
        
        for prov_id, profile in profiles.items():
            if profile.risk_score < 30:
                continue
            
            degree = G.degree(prov_id) if prov_id in G else 0
            btwn = betweenness.get(prov_id, 0)
            
            suspicious.append({
                "provider_id": prov_id,
                "risk_score": profile.risk_score,
                "flag_rate": profile.flag_rate,
                "flagged_claims": profile.flagged_claims,
                "total_claims": profile.total_claims,
                "flagged_amount": profile.flagged_amount,
                "degree": degree,
                "betweenness": round(btwn, 4),
                "top_anomalies": profile.top_anomaly_types,
                "reason": self._infer_reason(profile, degree, btwn)
            })
        
        suspicious.sort(key=lambda x: x["risk_score"], reverse=True)
        return suspicious[:20]
    
    def _find_hubs(self, G: 'nx.Graph', profiles: Dict) -> List[Dict]:
        """비정상적으로 많은 연결을 가진 Hub Provider"""
        if G.number_of_nodes() == 0:
            return []
        
        degrees = dict(G.degree())
        avg_degree = np.mean(list(degrees.values())) if degrees else 0
        std_degree = np.std(list(degrees.values())) if degrees else 0
        threshold = avg_degree + 2 * std_degree
        
        hubs = []
        for prov_id, degree in degrees.items():
            if degree > threshold and degree > 3:
                profile = profiles.get(prov_id)
                hubs.append({
                    "provider_id": prov_id,
                    "degree": degree,
                    "avg_degree": round(avg_degree, 1),
                    "threshold": round(threshold, 1),
                    "risk_score": profile.risk_score if profile else 0,
                    "flag_rate": profile.flag_rate if profile else 0,
                    "alert": "Hub provider — 비정상적으로 많은 의뢰 연결"
                })
        
        hubs.sort(key=lambda x: x["degree"], reverse=True)
        return hubs[:10]
    
    def _find_referral_anomalies(self, G: 'nx.Graph', df: pd.DataFrame, profiles: Dict) -> List[Dict]:
        """이상 의뢰 패턴 탐지"""
        anomalies = []
        
        for u, v, data in G.edges(data=True):
            shared = data.get("shared_patients", 0)
            u_profile = profiles.get(u)
            v_profile = profiles.get(v)
            
            if not u_profile or not v_profile:
                continue
            
            # 두 Provider 모두 높은 위반율 + 많은 환자 공유
            if u_profile.flag_rate > 0.3 and v_profile.flag_rate > 0.3 and shared >= 3:
                anomalies.append({
                    "provider_a": u,
                    "provider_b": v,
                    "shared_patients": shared,
                    "a_flag_rate": u_profile.flag_rate,
                    "b_flag_rate": v_profile.flag_rate,
                    "combined_flagged_amount": u_profile.flagged_amount + v_profile.flagged_amount,
                    "alert": "의심 의뢰 패턴 — 양쪽 모두 높은 위반율로 환자 공유",
                    "severity": "CRITICAL" if shared >= 5 else "WARNING"
                })
        
        anomalies.sort(key=lambda x: x["shared_patients"], reverse=True)
        return anomalies[:10]
    
    def _find_suspicious_by_stats(self, profiles: Dict) -> List[Dict]:
        """NetworkX 미설치 시 통계 기반 탐지"""
        suspicious = []
        for prov_id, p in profiles.items():
            if p.risk_score >= 30:
                suspicious.append({
                    "provider_id": prov_id,
                    "risk_score": p.risk_score,
                    "flag_rate": p.flag_rate,
                    "flagged_claims": p.flagged_claims,
                    "total_claims": p.total_claims,
                    "flagged_amount": p.flagged_amount,
                    "reason": "High flag rate" if p.flag_rate > 0.5 else "Elevated risk"
                })
        suspicious.sort(key=lambda x: x["risk_score"], reverse=True)
        return suspicious[:20]
    
    @staticmethod
    def _infer_reason(profile: ProviderProfile, degree: int, btwn: float) -> str:
        reasons = []
        if profile.flag_rate > 0.5:
            reasons.append("매우 높은 위반율")
        if "HCC_UPCODING" in profile.top_anomaly_types:
            reasons.append("반복 HCC Upcoding")
        if "GLP1_MISUSE" in profile.top_anomaly_types:
            reasons.append("GLP-1 오남용 집중")
        if degree > 5:
            reasons.append(f"높은 연결성(degree={degree})")
        if btwn > 0.1:
            reasons.append("네트워크 매개 역할")
        return " | ".join(reasons) if reasons else "종합 리스크 높음"
