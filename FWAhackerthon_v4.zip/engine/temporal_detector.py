"""
시계열 이상 탐지 모듈 (Temporal Anomaly Detection)
===================================================
시간 흐름에 따른 청구 패턴 변화를 분석하여 이상 징후 탐지.

탐지 패턴:
  - 월별 청구 급증 (Volume Spike)
  - 연말 업코딩 (End-of-Year Upcoding)
  - 주말/공휴일 이상 청구 (Weekend Billing)
  - Provider별 시간 패턴 변화
  - 이동 평균 + Z-score 기반 이상 탐지
"""
import pandas as pd
import numpy as np
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field, asdict
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)


@dataclass
class TemporalAnomaly:
    """시계열 이상 탐지 결과 단위"""
    anomaly_type: str           # VOLUME_SPIKE / EOY_UPCODING / WEEKEND_BILLING / PATTERN_SHIFT
    severity: str               # CRITICAL / WARNING / INFO
    period: str                 # "2024-03", "2024-W12" 등
    description: str
    affected_claims: int = 0
    affected_amount: float = 0.0
    z_score: float = 0.0
    provider_id: str = ""
    evidence: Dict = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        return asdict(self)


@dataclass
class TemporalAnalysisResult:
    """시계열 분석 종합 결과"""
    monthly_trends: List[Dict] = field(default_factory=list)
    weekly_trends: List[Dict] = field(default_factory=list)
    anomalies: List[Dict] = field(default_factory=list)
    provider_temporal: List[Dict] = field(default_factory=list)
    summary: Dict = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        return asdict(self)


class TemporalAnomalyDetector:
    """
    시계열 이상 탐지기.
    
    이동 평균(MA) + Z-score 기반으로 청구 패턴의 이상 변화를 탐지.
    
    Usage:
        detector = TemporalAnomalyDetector()
        result = detector.analyze(df)
    """
    
    def __init__(self, z_threshold: float = 2.0, ma_window: int = 3):
        """
        Args:
            z_threshold: Z-score 이상 탐지 임계값 (기본 2.0 = 95% 신뢰)
            ma_window: 이동 평균 윈도우 크기 (월 단위)
        """
        self.z_threshold = z_threshold
        self.ma_window = ma_window
    
    def analyze(self, df: pd.DataFrame) -> TemporalAnalysisResult:
        """
        전체 시계열 분석 실행.
        
        Args:
            df: DataFrame (claim_date, claim_amount, provider_id 등 필요)
        Returns:
            TemporalAnalysisResult
        """
        result = TemporalAnalysisResult()
        
        if "claim_date" not in df.columns:
            logger.warning("claim_date column missing")
            return result
        
        # 날짜 변환
        df = df.copy()
        df["claim_date"] = pd.to_datetime(df["claim_date"], errors="coerce")
        df = df.dropna(subset=["claim_date"])
        
        if len(df) == 0:
            return result
        
        df["year_month"] = df["claim_date"].dt.to_period("M").astype(str)
        df["week"] = df["claim_date"].dt.isocalendar().week.astype(int)
        df["day_of_week"] = df["claim_date"].dt.dayofweek  # 0=Mon, 6=Sun
        df["month"] = df["claim_date"].dt.month
        df["year"] = df["claim_date"].dt.year
        
        all_anomalies = []
        
        # 1. 월별 추이 분석
        result.monthly_trends = self._monthly_trends(df)
        
        # 2. 월별 볼륨 스파이크 탐지
        spikes = self._detect_volume_spikes(df)
        all_anomalies.extend(spikes)
        
        # 3. 연말 업코딩 패턴
        eoy = self._detect_eoy_upcoding(df)
        all_anomalies.extend(eoy)
        
        # 4. 주말/공휴일 이상 청구
        weekend = self._detect_weekend_billing(df)
        all_anomalies.extend(weekend)
        
        # 5. Provider별 시간 패턴 변화
        provider_shifts = self._detect_provider_shifts(df)
        all_anomalies.extend(provider_shifts)
        result.provider_temporal = self._provider_monthly_breakdown(df)
        
        # 6. 주간 추이
        result.weekly_trends = self._weekly_trends(df)
        
        # 결과 정리
        result.anomalies = [a.to_dict() for a in all_anomalies]
        result.anomalies.sort(key=lambda x: {"CRITICAL": 0, "WARNING": 1, "INFO": 2}.get(x["severity"], 3))
        
        result.summary = {
            "total_anomalies": len(all_anomalies),
            "critical": sum(1 for a in all_anomalies if a.severity == "CRITICAL"),
            "warning": sum(1 for a in all_anomalies if a.severity == "WARNING"),
            "info": sum(1 for a in all_anomalies if a.severity == "INFO"),
            "date_range": f"{df['claim_date'].min().date()} ~ {df['claim_date'].max().date()}",
            "total_months": df["year_month"].nunique(),
        }
        
        return result
    
    def _monthly_trends(self, df: pd.DataFrame) -> List[Dict]:
        """월별 청구 추이 계산"""
        monthly = df.groupby("year_month").agg(
            claim_count=("claim_date", "count"),
            total_amount=("claim_amount", "sum") if "claim_amount" in df.columns else ("claim_date", "count"),
            avg_amount=("claim_amount", "mean") if "claim_amount" in df.columns else ("claim_date", "count"),
            unique_providers=("provider_id", "nunique") if "provider_id" in df.columns else ("claim_date", "count"),
            unique_patients=("patient_id", "nunique") if "patient_id" in df.columns else ("claim_date", "count"),
        ).reset_index()
        
        # 플래그 비율
        if "is_flagged" in df.columns:
            flagged = df[df["is_flagged"]].groupby("year_month").size().reset_index(name="flagged_count")
            monthly = monthly.merge(flagged, on="year_month", how="left")
            monthly["flagged_count"] = monthly["flagged_count"].fillna(0).astype(int)
            monthly["flag_rate"] = monthly["flagged_count"] / monthly["claim_count"]
        
        # 이동 평균
        monthly["ma_count"] = monthly["claim_count"].rolling(window=self.ma_window, min_periods=1).mean()
        monthly["ma_amount"] = monthly["total_amount"].rolling(window=self.ma_window, min_periods=1).mean()
        
        return monthly.round(2).to_dict(orient="records")
    
    def _weekly_trends(self, df: pd.DataFrame) -> List[Dict]:
        """요일별 청구 분포"""
        day_names = {0: "Mon", 1: "Tue", 2: "Wed", 3: "Thu", 4: "Fri", 5: "Sat", 6: "Sun"}
        
        daily = df.groupby("day_of_week").agg(
            claim_count=("claim_date", "count"),
            avg_amount=("claim_amount", "mean") if "claim_amount" in df.columns else ("claim_date", "count"),
        ).reset_index()
        
        daily["day_name"] = daily["day_of_week"].map(day_names)
        
        if "is_flagged" in df.columns:
            flagged_daily = df[df["is_flagged"]].groupby("day_of_week").size().reset_index(name="flagged_count")
            daily = daily.merge(flagged_daily, on="day_of_week", how="left")
            daily["flagged_count"] = daily["flagged_count"].fillna(0).astype(int)
        
        return daily.round(2).to_dict(orient="records")
    
    def _detect_volume_spikes(self, df: pd.DataFrame) -> List[TemporalAnomaly]:
        """월별 볼륨 급증 탐지 (Z-score)"""
        anomalies = []
        
        monthly_counts = df.groupby("year_month").size()
        if len(monthly_counts) < 3:
            return anomalies
        
        mean_count = monthly_counts.mean()
        std_count = monthly_counts.std()
        
        if std_count == 0:
            return anomalies
        
        for month, count in monthly_counts.items():
            z = (count - mean_count) / std_count
            
            if abs(z) >= self.z_threshold:
                month_df = df[df["year_month"] == month]
                amount = month_df["claim_amount"].sum() if "claim_amount" in df.columns else 0
                
                severity = "CRITICAL" if abs(z) >= 3.0 else "WARNING"
                direction = "급증" if z > 0 else "급감"
                
                anomalies.append(TemporalAnomaly(
                    anomaly_type="VOLUME_SPIKE",
                    severity=severity,
                    period=str(month),
                    description=f"{month} 청구 건수 {direction}: {count}건 (평균 {mean_count:.0f}건, z={z:.2f})",
                    affected_claims=int(count),
                    affected_amount=round(amount, 2),
                    z_score=round(z, 2),
                    evidence={
                        "count": int(count),
                        "mean": round(mean_count, 1),
                        "std": round(std_count, 1),
                        "direction": "increase" if z > 0 else "decrease"
                    }
                ))
        
        # 금액 급증도 체크
        if "claim_amount" in df.columns:
            monthly_amounts = df.groupby("year_month")["claim_amount"].sum()
            mean_amt = monthly_amounts.mean()
            std_amt = monthly_amounts.std()
            
            if std_amt > 0:
                for month, amount in monthly_amounts.items():
                    z = (amount - mean_amt) / std_amt
                    if z >= self.z_threshold:
                        # 볼륨 스파이크와 중복 방지
                        already = any(a.period == str(month) and a.anomaly_type == "VOLUME_SPIKE" for a in anomalies)
                        if not already:
                            anomalies.append(TemporalAnomaly(
                                anomaly_type="VOLUME_SPIKE",
                                severity="WARNING",
                                period=str(month),
                                description=f"{month} 청구 금액 급증: ${amount:,.0f} (평균 ${mean_amt:,.0f})",
                                affected_amount=round(amount, 2),
                                z_score=round(z, 2),
                                evidence={"amount": round(amount, 2), "mean_amount": round(mean_amt, 2)}
                            ))
        
        return anomalies
    
    def _detect_eoy_upcoding(self, df: pd.DataFrame) -> List[TemporalAnomaly]:
        """연말(Q4) 업코딩 패턴 탐지 — 보험 연도 마감 전 보험금 극대화"""
        anomalies = []
        
        if "is_flagged" not in df.columns:
            return anomalies
        
        # Q4 (10-12월) vs 나머지 비교
        df_q4 = df[df["month"].isin([10, 11, 12])]
        df_rest = df[~df["month"].isin([10, 11, 12])]
        
        if len(df_q4) == 0 or len(df_rest) == 0:
            return anomalies
        
        q4_flag_rate = df_q4["is_flagged"].mean()
        rest_flag_rate = df_rest["is_flagged"].mean()
        
        if rest_flag_rate > 0 and q4_flag_rate / rest_flag_rate > 1.3:
            ratio = q4_flag_rate / rest_flag_rate
            severity = "CRITICAL" if ratio > 2.0 else "WARNING"
            
            anomalies.append(TemporalAnomaly(
                anomaly_type="EOY_UPCODING",
                severity=severity,
                period="Q4",
                description=f"Q4 위반율 {q4_flag_rate:.1%} vs 나머지 {rest_flag_rate:.1%} (x{ratio:.1f}배)",
                affected_claims=int(df_q4["is_flagged"].sum()),
                affected_amount=round(
                    df_q4[df_q4["is_flagged"]]["claim_amount"].sum(), 2
                ) if "claim_amount" in df.columns else 0,
                evidence={
                    "q4_flag_rate": round(q4_flag_rate, 3),
                    "rest_flag_rate": round(rest_flag_rate, 3),
                    "ratio": round(ratio, 2)
                }
            ))
        
        # HCC 업코딩 연말 집중 체크
        if "anomaly_type" in df.columns:
            q4_hcc = df_q4[df_q4["anomaly_type"] == "HCC_UPCODING"]
            rest_hcc = df_rest[df_rest["anomaly_type"] == "HCC_UPCODING"]
            
            if len(rest_hcc) > 0:
                q4_hcc_rate = len(q4_hcc) / len(df_q4)
                rest_hcc_rate = len(rest_hcc) / len(df_rest)
                
                if rest_hcc_rate > 0 and q4_hcc_rate / rest_hcc_rate > 1.5:
                    anomalies.append(TemporalAnomaly(
                        anomaly_type="EOY_UPCODING",
                        severity="CRITICAL",
                        period="Q4-HCC",
                        description=f"Q4 HCC Upcoding 집중: {q4_hcc_rate:.1%} vs 나머지 {rest_hcc_rate:.1%}",
                        affected_claims=len(q4_hcc),
                        evidence={"q4_hcc_rate": round(q4_hcc_rate, 4), "rest_hcc_rate": round(rest_hcc_rate, 4)}
                    ))
        
        return anomalies
    
    def _detect_weekend_billing(self, df: pd.DataFrame) -> List[TemporalAnomaly]:
        """주말 이상 청구 탐지"""
        anomalies = []
        
        weekend = df[df["day_of_week"].isin([5, 6])]
        weekday = df[~df["day_of_week"].isin([5, 6])]
        
        if len(weekend) == 0 or len(weekday) == 0:
            return anomalies
        
        # 주말 일평균 vs 평일 일평균
        weekend_daily = len(weekend) / max(df["claim_date"].dt.date.nunique(), 1)
        weekday_daily = len(weekday) / max(df["claim_date"].dt.date.nunique(), 1)
        
        if "is_flagged" in df.columns:
            wkend_flag_rate = weekend["is_flagged"].mean() if len(weekend) > 0 else 0
            wkday_flag_rate = weekday["is_flagged"].mean() if len(weekday) > 0 else 0
            
            if wkday_flag_rate > 0 and wkend_flag_rate / wkday_flag_rate > 1.5:
                ratio = wkend_flag_rate / wkday_flag_rate
                anomalies.append(TemporalAnomaly(
                    anomaly_type="WEEKEND_BILLING",
                    severity="WARNING",
                    period="Weekend",
                    description=f"주말 위반율 {wkend_flag_rate:.1%} vs 평일 {wkday_flag_rate:.1%} (x{ratio:.1f}배)",
                    affected_claims=int(weekend["is_flagged"].sum()) if "is_flagged" in weekend.columns else 0,
                    evidence={
                        "weekend_flag_rate": round(wkend_flag_rate, 3),
                        "weekday_flag_rate": round(wkday_flag_rate, 3),
                    }
                ))
        
        # Provider별 주말 집중 청구
        if "provider_id" in df.columns:
            prov_weekend = weekend.groupby("provider_id").size()
            prov_total = df.groupby("provider_id").size()
            prov_weekend_ratio = (prov_weekend / prov_total).dropna()
            
            for prov_id, ratio in prov_weekend_ratio.items():
                if ratio > 0.4 and prov_total[prov_id] >= 5:
                    anomalies.append(TemporalAnomaly(
                        anomaly_type="WEEKEND_BILLING",
                        severity="WARNING",
                        period="Weekend",
                        description=f"{prov_id}: 주말 청구 비율 {ratio:.1%} ({prov_weekend[prov_id]}건/{prov_total[prov_id]}건)",
                        provider_id=prov_id,
                        affected_claims=int(prov_weekend[prov_id]),
                        evidence={"weekend_ratio": round(ratio, 3)}
                    ))
        
        return anomalies
    
    def _detect_provider_shifts(self, df: pd.DataFrame) -> List[TemporalAnomaly]:
        """Provider별 시간 패턴 급변 탐지"""
        anomalies = []
        
        if "provider_id" not in df.columns:
            return anomalies
        
        months = sorted(df["year_month"].unique())
        if len(months) < 3:
            return anomalies
        
        for prov_id, group in df.groupby("provider_id"):
            if len(group) < 10:
                continue
            
            monthly = group.groupby("year_month").size()
            if len(monthly) < 3:
                continue
            
            mean_count = monthly.mean()
            std_count = monthly.std()
            
            if std_count == 0:
                continue
            
            for month, count in monthly.items():
                z = (count - mean_count) / std_count
                if z >= self.z_threshold + 0.5:  # Provider 레벨은 더 높은 임계값
                    anomalies.append(TemporalAnomaly(
                        anomaly_type="PATTERN_SHIFT",
                        severity="WARNING",
                        period=str(month),
                        provider_id=prov_id,
                        description=f"{prov_id}: {month} 청구 급증 {count}건 (평균 {mean_count:.0f}건, z={z:.1f})",
                        affected_claims=int(count),
                        z_score=round(z, 2),
                        evidence={"provider_mean": round(mean_count, 1), "count": int(count)}
                    ))
        
        return anomalies
    
    def _provider_monthly_breakdown(self, df: pd.DataFrame) -> List[Dict]:
        """Provider별 월간 분석 (Top 10 high-risk)"""
        if "provider_id" not in df.columns:
            return []
        
        provider_stats = []
        
        for prov_id, group in df.groupby("provider_id"):
            total = len(group)
            flagged = group["is_flagged"].sum() if "is_flagged" in group.columns else 0
            flag_rate = flagged / total if total > 0 else 0
            
            monthly = group.groupby("year_month").size().to_dict()
            
            provider_stats.append({
                "provider_id": prov_id,
                "total_claims": total,
                "flagged_claims": int(flagged),
                "flag_rate": round(flag_rate, 3),
                "monthly_claims": monthly,
                "months_active": len(monthly),
                "max_month_claims": max(monthly.values()) if monthly else 0,
            })
        
        provider_stats.sort(key=lambda x: x["flag_rate"], reverse=True)
        return provider_stats[:10]
