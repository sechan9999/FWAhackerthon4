"""
FWA Detection Intelligence Dashboard v4.0
==========================================
7대 개선사항 통합 대시보드:
  1. LangGraph 다단계 에이전트 파이프라인
  2. Streamlit Cloud 자동 배포 (GitHub Actions)
  3. Provider 네트워크 분석 (Graph)
  4. 시계열 이상 탐지 (Temporal Anomaly Detection)
  5. Slack/Teams 실시간 알림
  6. AWS SageMaker 대용량 배치 연동
  7. 다국어 지원 (한국어/영어)

Run:
  streamlit run app/fwa_dashboard.py
"""
import streamlit as st
import pandas as pd
import numpy as np
import json
import os
import sys
from datetime import datetime

# 엔진 경로 추가 (Windows / Linux 호환)
_APP_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJECT_ROOT = os.path.dirname(_APP_DIR)
sys.path.insert(0, _PROJECT_ROOT)

from engine.rules import RxHCCRuleEngine, ClaimRecord, Severity
from engine.sagemaker_replication import SyntheticClaimGenerator, PandasBatchValidator, SageMakerProcessor
from engine.i18n import t, set_language, get_language, get_all_languages

# Optional imports
try:
    from engine.ai_analyzer import FWAAIAnalyzer, OPENAI_AVAILABLE
except ImportError:
    OPENAI_AVAILABLE = False

try:
    from engine.langgraph_pipeline import run_fwa_pipeline, LANGGRAPH_AVAILABLE
except ImportError:
    LANGGRAPH_AVAILABLE = False

try:
    from engine.provider_network import ProviderNetworkAnalyzer, NETWORKX_AVAILABLE
except ImportError:
    NETWORKX_AVAILABLE = False

try:
    from engine.temporal_detector import TemporalAnomalyDetector
    TEMPORAL_AVAILABLE = True
except ImportError:
    TEMPORAL_AVAILABLE = False

try:
    from engine.alerts import AlertManager
    ALERTS_AVAILABLE = True
except ImportError:
    ALERTS_AVAILABLE = False


# ============================================================
# 페이지 설정
# ============================================================
st.set_page_config(
    page_title="FWA Detection Intelligence",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ============================================================
# 커스텀 CSS
# ============================================================
st.markdown("""
<style>
    .risk-badge-high { background: linear-gradient(135deg, #FF4444, #CC0000); color: white;
        padding: 4px 12px; border-radius: 12px; font-weight: bold; display: inline-block; }
    .risk-badge-medium { background: linear-gradient(135deg, #FFA500, #FF8C00); color: white;
        padding: 4px 12px; border-radius: 12px; font-weight: bold; display: inline-block; }
    .risk-badge-low { background: linear-gradient(135deg, #4CAF50, #2E7D32); color: white;
        padding: 4px 12px; border-radius: 12px; font-weight: bold; display: inline-block; }
    .risk-badge-clean { background: linear-gradient(135deg, #2196F3, #1565C0); color: white;
        padding: 4px 12px; border-radius: 12px; font-weight: bold; display: inline-block; }
    .action-block { background: #FF0000; color: white; padding: 4px 12px; border-radius: 12px;
        font-weight: bold; display: inline-block; }
    .action-review { background: #FF8C00; color: white; padding: 4px 12px; border-radius: 12px;
        font-weight: bold; display: inline-block; }
    .action-monitor { background: #FFD700; color: #333; padding: 4px 12px; border-radius: 12px;
        font-weight: bold; display: inline-block; }
    .action-approve { background: #4CAF50; color: white; padding: 4px 12px; border-radius: 12px;
        font-weight: bold; display: inline-block; }
    .ai-badge { background: linear-gradient(135deg, #667eea, #764ba2); color: white;
        padding: 6px 16px; border-radius: 16px; font-weight: bold; display: inline-block; }
    .pipeline-step { border-left: 3px solid #667eea; padding: 8px 12px; margin: 4px 0;
        background: #f8f9fa; border-radius: 0 8px 8px 0; }
</style>
""", unsafe_allow_html=True)


# ============================================================
# 사이드바 설정
# ============================================================
def setup_sidebar():
    with st.sidebar:
        st.title(t("sidebar.title"))
        st.caption(t("sidebar.subtitle"))
        st.divider()

        # 🌐 언어 선택
        langs = get_all_languages()
        current = get_language()
        lang_choice = st.selectbox(
            t("alerts.lang_section"),
            list(langs.keys()),
            index=list(langs.keys()).index(current),
            format_func=lambda x: langs[x]
        )
        if lang_choice != current:
            set_language(lang_choice)
            st.session_state["lang"] = lang_choice
            st.rerun()

        st.divider()

        # OpenAI 설정
        st.subheader(t("sidebar.openai_settings"))
        api_key = st.text_input("OpenAI API Key", type="password",
                                value=st.session_state.get("openai_api_key", ""))
        if api_key:
            st.session_state["openai_api_key"] = api_key
            os.environ["OPENAI_API_KEY"] = api_key

        model = st.selectbox("Model", ["gpt-4o-mini", "gpt-4o", "gpt-4-turbo"], index=0)
        st.session_state["model"] = model

        st.divider()

        # 시스템 상태
        st.subheader(t("sidebar.system_status"))
        if st.session_state.get("openai_api_key"):
            st.success(t("sidebar.api_connected"))
        else:
            st.warning(t("sidebar.api_missing"))

        if LANGGRAPH_AVAILABLE:
            st.success(t("sidebar.langgraph_active"))
        else:
            st.info(t("sidebar.langgraph_seq"))

        for name, avail in [("NetworkX", NETWORKX_AVAILABLE), ("Temporal", TEMPORAL_AVAILABLE), ("Alerts", ALERTS_AVAILABLE)]:
            if avail:
                st.success(f"✅ {name}")
            else:
                st.info(f"⚠️ {name} (fallback)")


# ============================================================
# 유틸리티 함수
# ============================================================
def get_ai_analyzer():
    api_key = st.session_state.get("openai_api_key")
    model = st.session_state.get("model", "gpt-4o-mini")
    if api_key and OPENAI_AVAILABLE:
        return FWAAIAnalyzer(api_key=api_key, model=model)
    return FWAAIAnalyzer() if OPENAI_AVAILABLE else None

def render_risk_badge(level):
    css = {"HIGH": "risk-badge-high", "MEDIUM": "risk-badge-medium",
           "LOW": "risk-badge-low", "CLEAN": "risk-badge-clean",
           "MINIMAL": "risk-badge-clean"}.get(level, "risk-badge-low")
    st.markdown(f'<span class="{css}">{level}</span>', unsafe_allow_html=True)

def render_action_badge(action):
    css = {"BLOCK": "action-block", "REVIEW": "action-review",
           "MONITOR": "action-monitor", "APPROVE": "action-approve"}.get(action, "action-monitor")
    st.markdown(f'<span class="{css}">{action}</span>', unsafe_allow_html=True)

def get_test_scenarios():
    return {
        "✅ Normal (E11.9 + Metformin)": {
            "claim_id": "TEST-NORMAL-001", "patient_id": "PAT-9001",
            "icd_codes": "E11.9", "ndc_codes": "00002-1433-80",
            "hcc_codes": "HCC19", "provider_id": "PRV-100",
            "claim_date": "2024-06-15", "claim_amount": 250.00},
        "🔴 ICD Conflict (E10 + E11)": {
            "claim_id": "TEST-CONFLICT-001", "patient_id": "PAT-9002",
            "icd_codes": "E10.9,E11.9", "ndc_codes": "00002-1433-80",
            "hcc_codes": "HCC19", "provider_id": "PRV-200",
            "claim_date": "2024-06-15", "claim_amount": 450.00},
        "🔴 GLP-1 Misuse (I10 + Ozempic)": {
            "claim_id": "TEST-GLP1-001", "patient_id": "PAT-9003",
            "icd_codes": "I10", "ndc_codes": "00169-4060-12",
            "hcc_codes": "", "provider_id": "PRV-300",
            "claim_date": "2024-07-01", "claim_amount": 1200.00},
        "🔴 HCC Upcoding (E11.9 + HCC18)": {
            "claim_id": "TEST-HCC-001", "patient_id": "PAT-9004",
            "icd_codes": "E11.9", "ndc_codes": "00002-1433-80",
            "hcc_codes": "HCC18", "provider_id": "PRV-500",
            "claim_date": "2024-08-01", "claim_amount": 3500.00},
        "🟡 NDC Mismatch (I10 + Insulin)": {
            "claim_id": "TEST-NDC-001", "patient_id": "PAT-9005",
            "icd_codes": "I10", "ndc_codes": "00088-2500-33",
            "hcc_codes": "", "provider_id": "PRV-400",
            "claim_date": "2024-09-15", "claim_amount": 800.00},
    }


# ============================================================
# PAGE 1: AI 실시간 분석
# ============================================================
def page_realtime_scan():
    st.header(t("scan.title"))
    st.caption(t("scan.subtitle"))

    tab1, tab2 = st.tabs([t("scan.scenario_tab"), t("scan.manual_tab")])

    with tab1:
        scenarios = get_test_scenarios()
        choice = st.selectbox("Scenario", list(scenarios.keys()))
        claim = scenarios[choice]
        st.json(claim)
        if st.button(t("common.analyze"), key="scan_scenario"):
            _run_analysis(claim)

    with tab2:
        with st.form("manual_claim"):
            c1, c2 = st.columns(2)
            claim_id = c1.text_input("Claim ID", "MANUAL-001")
            patient_id = c2.text_input("Patient ID", "PAT-M001")
            icd_codes = c1.text_input("ICD Codes", "E11.9")
            ndc_codes = c2.text_input("NDC Codes", "00002-1433-80")
            hcc_codes = c1.text_input("HCC Codes", "HCC19")
            provider_id = c2.text_input("Provider ID", "PRV-M01")
            claim_date = c1.date_input("Claim Date")
            claim_amount = c2.number_input("Amount ($)", value=500.0, min_value=0.0)
            submitted = st.form_submit_button(t("common.analyze"))
        if submitted:
            claim = {"claim_id": claim_id, "patient_id": patient_id,
                     "icd_codes": icd_codes, "ndc_codes": ndc_codes,
                     "hcc_codes": hcc_codes, "provider_id": provider_id,
                     "claim_date": str(claim_date), "claim_amount": claim_amount}
            _run_analysis(claim)


def _run_analysis(claim):
    with st.spinner(t("common.loading")):
        try:
            result = run_fwa_pipeline(claim)
            _render_pipeline_result(result)
        except Exception as e:
            st.warning(f"Pipeline fallback: {e}")
            engine = RxHCCRuleEngine()
            record = ClaimRecord.from_dict(claim)
            rules = engine.validate(record)
            _render_rule_results(rules)


def _render_pipeline_result(state):
    st.subheader("🔄 LangGraph Pipeline Result")

    with st.expander("📋 Pipeline Execution Log", expanded=False):
        for log in state.get("logs", []):
            icon = {"ok": "✅", "error": "❌", "fallback": "⚠️", "skipped": "⏭️"}.get(log["status"], "ℹ️")
            st.markdown(f'<div class="pipeline-step">{icon} <b>[{log["stage"]}]</b> {log["message"]}</div>', unsafe_allow_html=True)

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Risk Score", f"{state.get('risk_score', 0):.1f}")
    with c2:
        render_risk_badge(state.get("risk_level", "MINIMAL"))
    with c3:
        render_action_badge(state.get("recommended_action", "APPROVE"))
    c4.metric("Engine", state.get("metadata", {}).get("engine", "unknown"))

    if state.get("rule_results"):
        st.subheader(t("scan.rule_detail"))
        for r in state["rule_results"]:
            sev = r.get("severity", "INFO")
            icon = {"CRITICAL": "🔴", "WARNING": "🟡", "PASS": "🟢", "INFO": "ℹ️"}.get(sev, "ℹ️")
            st.markdown(f"{icon} **[{sev}]** `{r.get('rule_id', '')}` — {r.get('message', '')}")

    if state.get("ai_analysis"):
        ai = state["ai_analysis"]
        st.subheader(t("scan.ai_result"))
        c1, c2, c3 = st.columns(3)
        c1.metric("Fraud Probability", f"{ai.get('fraud_probability', 0):.0%}")
        c2.metric("Confidence", f"{ai.get('confidence', 0):.0%}")
        with c3:
            render_risk_badge(ai.get("risk_level", "LOW"))
        if ai.get("analysis_summary"):
            st.info(f"📝 {ai['analysis_summary']}")
        if ai.get("medical_reasoning"):
            with st.expander(t("scan.medical_reason")):
                st.write(ai["medical_reasoning"])

    if state.get("alerts_sent"):
        st.success(f"📤 Alerts sent to: {', '.join(state['alerts_sent'])}")


def _render_rule_results(results):
    st.subheader(t("scan.rule_detail"))
    for r in results:
        sev = r.severity.value
        icon = {"CRITICAL": "🔴", "WARNING": "🟡", "PASS": "🟢", "INFO": "ℹ️"}.get(sev, "ℹ️")
        st.markdown(f"{icon} **[{sev}]** `{r.rule_id}` — {r.message}")


# ============================================================
# PAGE 2: 배치 검증 & 패턴
# ============================================================
def page_batch_pattern():
    st.header(t("batch.title"))

    tab1, tab2 = st.tabs(["🔬 Synthetic Data", "📁 CSV Upload"])
    with tab1:
        c1, c2 = st.columns(2)
        n_records = c1.slider(t("batch.records"), 100, 5000, 500, 100)
        anomaly_rate = c2.slider(t("batch.anomaly_rate"), 5, 40, 15) / 100
        if st.button(t("batch.generate"), key="batch_gen"):
            with st.spinner(t("common.loading")):
                gen = SyntheticClaimGenerator()
                df = gen.generate(n_records, anomaly_rate)
                validator = PandasBatchValidator()
                validated = validator.validate_dataframe(df)
                st.session_state["validated_df"] = validated
                st.session_state["batch_summary"] = validator.get_summary(validated)

    with tab2:
        uploaded = st.file_uploader("CSV File", type=["csv"])
        if uploaded:
            with st.spinner(t("common.loading")):
                df = pd.read_csv(uploaded)
                validator = PandasBatchValidator()
                validated = validator.validate_dataframe(df)
                st.session_state["validated_df"] = validated
                st.session_state["batch_summary"] = validator.get_summary(validated)

    if "batch_summary" in st.session_state:
        summary = st.session_state["batch_summary"]
        validated = st.session_state["validated_df"]

        c1, c2, c3, c4, c5 = st.columns(5)
        c1.metric(t("common.total_claims"), f"{summary['total_claims']:,}")
        c2.metric(t("common.flagged"), f"{summary['flagged_claims']:,}")
        c3.metric(t("common.pass_rate"), f"{summary['pass_rate']}%")
        c4.metric(t("common.total_amount"),
                  f"${validated['claim_amount'].sum():,.0f}" if "claim_amount" in validated.columns else "N/A")
        c5.metric(t("common.risk_amount"), f"${summary.get('total_amount_at_risk', 0):,.0f}")

        flagged_df = validated[validated["is_flagged"]]
        if len(flagged_df) > 0:
            display_cols = [c for c in ["claim_id", "patient_id", "provider_id", "icd_codes",
                                        "ndc_codes", "max_severity", "claim_amount", "anomaly_type"]
                           if c in flagged_df.columns]
            st.dataframe(flagged_df[display_cols].head(50), use_container_width=True)

        st.divider()
        if st.button(t("batch.pattern_run"), key="pattern_btn"):
            analyzer = get_ai_analyzer()
            if analyzer:
                with st.spinner("🧠 AI analyzing patterns..."):
                    claims_summary = f"Total: {summary['total_claims']}, Flagged: {summary['flagged_claims']}\n"
                    claims_summary += f"Severity: {json.dumps(summary.get('severity_distribution', {}))}\n"
                    claims_summary += f"Anomaly: {json.dumps(summary.get('anomaly_distribution', {}))}\n"
                    if len(flagged_df) > 0:
                        for _, row in flagged_df.head(30).iterrows():
                            claims_summary += f"\n{row.get('claim_id','')}: ICD={row.get('icd_codes','')}, NDC={row.get('ndc_codes','')}, Sev={row.get('max_severity','')}"
                    result = analyzer.detect_patterns(claims_summary, summary)
                    _render_pattern_result(result)
                    _try_send_batch_alert(summary)
            else:
                st.warning("OpenAI API key required.")


def _render_pattern_result(result):
    patterns = result.get("patterns_found", [])
    if patterns:
        st.subheader(t("batch.patterns_found"))
        for p in patterns:
            sev = p.get("severity", "WARNING")
            icon = "🔴" if sev == "CRITICAL" else "🟡"
            with st.expander(f"{icon} {p.get('pattern_name', 'Unknown')} — {sev}"):
                st.write(f"**Description:** {p.get('description', '')}")
                st.write(f"**Evidence:** {p.get('evidence', '')}")
                if p.get("affected_claims"):
                    st.write(f"**Affected:** {', '.join(str(c) for c in p['affected_claims'][:10])}")
                if p.get("estimated_impact_usd"):
                    st.write(f"**Impact:** ${p['estimated_impact_usd']:,.0f}")
    if result.get("overall_risk_assessment"):
        st.info(f"📋 {result['overall_risk_assessment']}")
    actions = result.get("priority_actions", [])
    if actions:
        st.subheader(t("batch.priority"))
        for i, a in enumerate(actions, 1):
            st.write(f"**{i}.** {a}")


def _try_send_batch_alert(summary):
    if not ALERTS_AVAILABLE:
        return
    slack_url = st.session_state.get("slack_webhook")
    teams_url = st.session_state.get("teams_webhook")
    if not slack_url and not teams_url:
        return
    try:
        mgr = AlertManager(slack_url=slack_url, teams_url=teams_url)
        sent = mgr.send_batch_summary(
            total_claims=summary["total_claims"],
            flagged_claims=summary["flagged_claims"],
            critical_count=summary.get("severity_distribution", {}).get("CRITICAL", 0),
            total_risk_amount=summary.get("total_amount_at_risk", 0),
            top_anomalies=list(summary.get("anomaly_distribution", {}).keys())
        )
        if sent:
            st.success(f"📤 Sent to: {', '.join(sent)}")
    except Exception:
        pass


# ============================================================
# PAGE 3: AI 수사관 Chat
# ============================================================
def page_investigator_chat():
    st.header(t("chat.title"))
    st.caption(t("chat.subtitle"))

    if "chat_history" not in st.session_state:
        st.session_state["chat_history"] = []

    with st.expander(t("chat.example_title")):
        for ex in t("chat.examples"):
            st.write(f"- {ex}")

    for msg in st.session_state["chat_history"]:
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"])

    user_input = st.chat_input(t("chat.placeholder"))
    if user_input:
        st.session_state["chat_history"].append({"role": "user", "content": user_input})
        with st.chat_message("user"):
            st.markdown(user_input)

        analyzer = get_ai_analyzer()
        if analyzer:
            context = json.dumps(st.session_state.get("batch_summary", {}), indent=2, ensure_ascii=False)
            with st.chat_message("assistant"):
                with st.spinner("🕵️ Investigating..."):
                    response = analyzer.investigate(user_input, context, st.session_state["chat_history"][-10:])
                    st.markdown(response)
                    st.session_state["chat_history"].append({"role": "assistant", "content": response})
        else:
            msg = "⚠️ OpenAI API key required."
            st.session_state["chat_history"].append({"role": "assistant", "content": msg})
            with st.chat_message("assistant"):
                st.markdown(msg)

    if st.sidebar.button(t("chat.clear")):
        st.session_state["chat_history"] = []
        st.rerun()


# ============================================================
# PAGE 4: Provider 네트워크 분석
# ============================================================
def page_provider_network():
    st.header(t("network.title"))
    st.caption(t("network.subtitle"))

    if "validated_df" not in st.session_state:
        st.info(t("dashboard.no_data"))
        if st.button(t("dashboard.generate_sample"), key="net_gen"):
            _quick_generate(500)
        return

    df = st.session_state["validated_df"]
    if st.button(t("network.run"), key="net_run"):
        with st.spinner("🕸️ Building provider network..."):
            analyzer = ProviderNetworkAnalyzer(shared_patient_threshold=2)
            result = analyzer.analyze(df)
            st.session_state["network_result"] = result.to_dict()

    if "network_result" in st.session_state:
        nr = st.session_state["network_result"]

        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Providers", nr.get("total_providers", 0))
        c2.metric("Connections", nr.get("total_edges", 0))
        c3.metric("Avg Degree", f"{nr.get('avg_degree', 0):.1f}")
        c4.metric("Density", f"{nr.get('density', 0):.3f}")

        suspicious = nr.get("suspicious_providers", [])
        if suspicious:
            st.subheader(t("network.suspicious"))
            st.dataframe(pd.DataFrame(suspicious), use_container_width=True)

        hubs = nr.get("hub_providers", [])
        if hubs:
            st.subheader("🔗 Hub Providers")
            st.dataframe(pd.DataFrame(hubs), use_container_width=True)

        clusters = nr.get("clusters", [])
        if clusters:
            st.subheader("🔗 Provider Clusters")
            for cl in clusters[:5]:
                risk = cl.get("risk_level", "LOW")
                icon = {"HIGH": "🔴", "MEDIUM": "🟡", "LOW": "🟢"}.get(risk, "🟢")
                with st.expander(f"{icon} Cluster #{cl['cluster_id']} — {cl['size']} members, Risk: {cl['avg_risk_score']:.0f}"):
                    st.write(f"**Members:** {', '.join(cl.get('members', [])[:10])}")

        referrals = nr.get("referral_anomalies", [])
        if referrals:
            st.subheader(t("network.referral"))
            st.dataframe(pd.DataFrame(referrals), use_container_width=True)


# ============================================================
# PAGE 5: 시계열 이상 탐지
# ============================================================
def page_temporal_anomaly():
    st.header(t("temporal.title"))
    st.caption(t("temporal.subtitle"))

    if "validated_df" not in st.session_state:
        st.info(t("dashboard.no_data"))
        if st.button(t("dashboard.generate_sample"), key="temp_gen"):
            _quick_generate(1000)
        return

    df = st.session_state["validated_df"]
    if st.button(t("temporal.run"), key="temp_run"):
        with st.spinner("📅 Analyzing temporal patterns..."):
            detector = TemporalAnomalyDetector(z_threshold=2.0, ma_window=3)
            result = detector.analyze(df)
            st.session_state["temporal_result"] = result.to_dict()

    if "temporal_result" in st.session_state:
        tr = st.session_state["temporal_result"]
        summary = tr.get("summary", {})

        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Total Anomalies", summary.get("total_anomalies", 0))
        c2.metric("🔴 Critical", summary.get("critical", 0))
        c3.metric("🟡 Warning", summary.get("warning", 0))
        c4.metric("Date Range", summary.get("date_range", "N/A"))

        monthly = tr.get("monthly_trends", [])
        if monthly:
            st.subheader(t("temporal.monthly_trend"))
            monthly_df = pd.DataFrame(monthly)
            if "claim_count" in monthly_df.columns and "year_month" in monthly_df.columns:
                st.line_chart(monthly_df.set_index("year_month")[["claim_count", "ma_count"]])
            if "flag_rate" in monthly_df.columns:
                st.caption("Flag Rate by Month")
                st.bar_chart(monthly_df.set_index("year_month")[["flag_rate"]])

        weekly = tr.get("weekly_trends", [])
        if weekly:
            st.subheader("📊 Day-of-Week Distribution")
            weekly_df = pd.DataFrame(weekly)
            if "day_name" in weekly_df.columns:
                st.bar_chart(weekly_df.set_index("day_name")[["claim_count"]])

        anomalies = tr.get("anomalies", [])
        if anomalies:
            st.subheader(t("temporal.spike_alert"))
            for a in anomalies:
                sev = a.get("severity", "INFO")
                icon = {"CRITICAL": "🔴", "WARNING": "🟡", "INFO": "ℹ️"}.get(sev, "ℹ️")
                with st.expander(f"{icon} [{sev}] {a.get('anomaly_type','')} — {a.get('period','')}"):
                    st.write(f"**Description:** {a.get('description', '')}")
                    if a.get("provider_id"):
                        st.write(f"**Provider:** {a['provider_id']}")
                    if a.get("z_score"):
                        st.write(f"**Z-Score:** {a['z_score']}")
                    if a.get("evidence"):
                        st.json(a["evidence"])

        prov = tr.get("provider_temporal", [])
        if prov:
            st.subheader("🏥 Provider Temporal (Top 10)")
            pt_df = pd.DataFrame(prov)
            cols = [c for c in ["provider_id", "total_claims", "flagged_claims", "flag_rate", "months_active"] if c in pt_df.columns]
            st.dataframe(pt_df[cols], use_container_width=True)


# ============================================================
# PAGE 6: 규칙 사전
# ============================================================
def page_rule_dictionary():
    st.header(t("nav.rule_dict"))
    from engine.rules import ICD_NDC_VALID_MAPPINGS, ICD_CONFLICT_RULES, GLP1_RULES, HCC_RULES

    st.subheader("💊 ICD-NDC Mapping Rules")
    for icd_prefix, info in ICD_NDC_VALID_MAPPINGS.items():
        with st.expander(f"`{icd_prefix}` — {info['description']}"):
            for ndc in info["valid_ndc_prefixes"]:
                st.write(f"  ✅ `{ndc}`")

    st.subheader("⚡ ICD Conflict Rules")
    for rule in ICD_CONFLICT_RULES:
        codes_a = ", ".join(rule.get("codes_a", []))
        codes_b = ", ".join(rule.get("codes_b", []))
        name = rule.get("name", "")
        st.write(f"🚫 `{codes_a}` ↔ `{codes_b}` — {name}")

    st.subheader("💉 GLP-1 Rules")
    st.write(f"**Valid indications:** {', '.join(GLP1_RULES.get('valid_indications', []))}")
    st.write(f"**Monitored NDC:** {', '.join(GLP1_RULES.get('glp1_ndc_prefixes', []))}")

    st.subheader("📊 HCC Rules")
    for hcc_code, info in HCC_RULES.items():
        st.write(f"**{hcc_code}** — Required ICD: `{', '.join(info.get('required_icd_patterns', []))}` | Impact: +{info.get('risk_score_impact', 0)}")


# ============================================================
# PAGE 7: 분석 대시보드
# ============================================================
def page_analytics_dashboard():
    st.header(t("dashboard.title"))

    if "validated_df" not in st.session_state:
        st.info(t("dashboard.no_data"))
        if st.button(t("dashboard.generate_sample"), key="dash_gen"):
            _quick_generate(500)
        return

    validated = st.session_state["validated_df"]
    summary = st.session_state.get("batch_summary", {})

    c1, c2, c3, c4, c5 = st.columns(5)
    c1.metric(t("common.total_claims"), f"{summary.get('total_claims', len(validated)):,}")
    c2.metric(t("common.flagged"), f"{summary.get('flagged_claims', 0):,}")
    c3.metric(t("common.pass_rate"), f"{summary.get('pass_rate', 0)}%")
    c4.metric(t("common.total_amount"), f"${validated['claim_amount'].sum():,.0f}" if "claim_amount" in validated.columns else "N/A")
    c5.metric(t("common.risk_amount"), f"${summary.get('total_amount_at_risk', 0):,.0f}")

    col1, col2 = st.columns(2)
    with col1:
        st.subheader(t("dashboard.severity_dist"))
        st.bar_chart(validated["max_severity"].value_counts())
    with col2:
        st.subheader(t("dashboard.anomaly_dist"))
        if "anomaly_type" in validated.columns:
            st.bar_chart(validated["anomaly_type"].value_counts())

    st.subheader(t("dashboard.provider_rank"))
    if "provider_id" in validated.columns:
        prov = validated.groupby("provider_id").agg(total=("is_flagged", "count"), flagged=("is_flagged", "sum")).reset_index()
        prov["flag_rate"] = (prov["flagged"] / prov["total"]).round(3)
        st.dataframe(prov.sort_values("flag_rate", ascending=False).head(10), use_container_width=True)

    csv = validated.to_csv(index=False).encode("utf-8")
    st.download_button(t("common.download_csv"), csv, "fwa_validated.csv", "text/csv")


# ============================================================
# PAGE 8: 설정 & 알림
# ============================================================
def page_settings_alerts():
    st.header(t("alerts.title"))

    st.subheader(t("alerts.slack_section"))
    slack_url = st.text_input(f"Slack {t('alerts.webhook_url')}", value=st.session_state.get("slack_webhook", ""), type="password", key="slack_in")
    if slack_url:
        st.session_state["slack_webhook"] = slack_url

    st.subheader(t("alerts.teams_section"))
    teams_url = st.text_input(f"Teams {t('alerts.webhook_url')}", value=st.session_state.get("teams_webhook", ""), type="password", key="teams_in")
    if teams_url:
        st.session_state["teams_webhook"] = teams_url

    if st.button(t("alerts.test_send")):
        if ALERTS_AVAILABLE:
            mgr = AlertManager(slack_url=slack_url, teams_url=teams_url)
            results = mgr.send_test()
            for ch, ok in results.items():
                st.success(f"✅ {ch}") if ok else st.error(f"❌ {ch}")
        else:
            st.warning("requests package required.")

    st.divider()

    st.subheader(t("alerts.sagemaker_section"))
    sage_role = st.text_input("SageMaker IAM Role ARN", value=st.session_state.get("sagemaker_role", ""))
    sage_bucket = st.text_input("S3 Bucket", value=st.session_state.get("s3_bucket", ""))
    sage_instance = st.selectbox("Instance Type", ["ml.m5.xlarge", "ml.m5.2xlarge", "ml.m5.4xlarge", "ml.c5.xlarge"])
    chunk_size = st.slider("Chunk Size", 1000, 50000, 5000, 1000)

    if sage_role:
        st.session_state["sagemaker_role"] = sage_role
    if sage_bucket:
        st.session_state["s3_bucket"] = sage_bucket

    st.divider()
    st.subheader("☁️ SageMaker Batch Processing")
    uploaded = st.file_uploader("Large CSV", type=["csv"], key="sage_up")
    if uploaded and st.button("🚀 Run SageMaker Batch"):
        import tempfile
        with tempfile.NamedTemporaryFile(suffix=".csv", delete=False) as tmp:
            tmp.write(uploaded.read())
            input_path = tmp.name
        output_path = input_path.replace(".csv", "_validated.csv")
        processor = SageMakerProcessor(role=sage_role, instance_type=sage_instance, chunk_size=chunk_size)
        progress = st.progress(0)
        def cb(cur, tot):
            progress.progress(cur / tot, text=f"{cur:,}/{tot:,}")
        result = processor.run_processing_job(input_path, output_path, progress_callback=cb)
        progress.progress(1.0, text="Complete!")
        st.json(result)
        try:
            validated = pd.read_csv(output_path)
            st.session_state["validated_df"] = validated
            st.session_state["batch_summary"] = PandasBatchValidator().get_summary(validated)
            st.success(f"✅ Processed {len(validated):,} claims")
        except Exception as e:
            st.error(f"Failed: {e}")


# ============================================================
# 유틸리티
# ============================================================
def _quick_generate(n=500):
    with st.spinner(t("common.loading")):
        gen = SyntheticClaimGenerator()
        df = gen.generate(n, 0.15)
        validator = PandasBatchValidator()
        validated = validator.validate_dataframe(df)
        st.session_state["validated_df"] = validated
        st.session_state["batch_summary"] = validator.get_summary(validated)
        st.rerun()


# ============================================================
# 메인
# ============================================================
def main():
    if "lang" in st.session_state:
        set_language(st.session_state["lang"])

    setup_sidebar()

    pages = {
        t("nav.realtime_scan"): page_realtime_scan,
        t("nav.batch_pattern"): page_batch_pattern,
        t("nav.investigator"): page_investigator_chat,
        t("nav.provider_network"): page_provider_network,
        t("nav.temporal"): page_temporal_anomaly,
        t("nav.rule_dict"): page_rule_dictionary,
        t("nav.dashboard"): page_analytics_dashboard,
        t("nav.settings"): page_settings_alerts,
    }

    selected = st.sidebar.radio("Navigation", list(pages.keys()))
    pages[selected]()


if __name__ == "__main__":
    main()
