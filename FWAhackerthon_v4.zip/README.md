# 🛡️ FWA Detection Intelligence

**OpenAI GPT + Rule Engine 기반 의료 보험 부정 청구 탐지 시스템**

> Healthcare Fraud, Waste & Abuse (FWA) 조기 탐지를 위한 실시간 검증 + AI 심층 분석 플랫폼

## Architecture

```
┌─────────────────────────────────────────────────────┐
│                  Streamlit Dashboard                  │
│  ┌──────────┐  ┌──────────┐  ┌────────────────────┐ │
│  │ Real-time│  │  Batch   │  │  AI Investigator   │ │
│  │ AI Scan  │  │ Validate │  │      Chat          │ │
│  └────┬─────┘  └────┬─────┘  └────────┬───────────┘ │
│       │              │                 │              │
│  ┌────▼──────────────▼─────────────────▼───────────┐ │
│  │              FWA AI Analyzer                      │ │
│  │  ┌──────────────┐  ┌─────────────────────────┐  │ │
│  │  │  Rule Engine  │  │  OpenAI GPT (gpt-4o)    │  │ │
│  │  │  • ICD-NDC    │  │  • Function Calling     │  │ │
│  │  │  • Conflicts  │──│  • Medical Reasoning    │  │ │
│  │  │  • GLP-1      │  │  • Pattern Detection    │  │ │
│  │  │  • HCC Upcode │  │  • Natural Language     │  │ │
│  │  └──────────────┘  └─────────────────────────┘  │ │
│  └─────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────┘
```

## 주요 기능

### 1. 🔍 실시간 AI 분석 (Real-time AI Scan)
- **룰엔진**: ICD-NDC 매핑 검증, ICD 충돌 탐지, GLP-1 오남용, HCC 업코딩
- **OpenAI GPT**: 룰엔진 결과를 의학적 맥락에서 심층 분석
- **Function Calling**: 구조화된 JSON 응답 (risk_level, fraud_probability, recommended_action)

### 2. 📊 배치 검증 & AI 패턴 탐지
- 합성 데이터 생성 (100~5,000건, 이상 비율 조절 가능)
- 대량 배치 검증 후 GPT가 **복합 부정 패턴** 자동 탐지
- Provider 패턴, Doctor Shopping, Temporal Spikes, Systematic Upcoding 등

### 3. 🕵️ AI 수사관 Chat (Investigator)
- 자연어로 청구 데이터 조사: "GLP-1 오남용 의심 건을 분석해줘"
- 대화 맥락 유지 (multi-turn)
- 데이터 기반 증거 인용

### 4. 📖 규칙 사전 & 📈 분석 대시보드
- 등록된 모든 검증 규칙 조회
- 심각도 분포, 이상 유형, Provider별 위반율 시각화
- CSV 다운로드

## Quick Start

```bash
# 1. 클론
git clone https://github.com/sechan9999/FWAdetection.git
cd FWAdetection

# 2. 의존성 설치
pip install -r requirements.txt

# 3. OpenAI API Key 설정 (선택 — 없으면 룰 기반 모드로 동작)
export OPENAI_API_KEY="sk-..."

# 4. 실행
streamlit run app/fwa_dashboard.py
```

## OpenAI API 활용 상세

### Function Calling Schema

```python
# 단건 분석 → submit_fwa_analysis
{
    "risk_level": "HIGH",           # HIGH / MEDIUM / LOW / CLEAN
    "confidence": 0.92,             # 분석 신뢰도
    "fraud_probability": 0.85,      # 부정 확률
    "analysis_summary": "...",      # 한글 요약
    "medical_reasoning": "...",     # 의학적 근거
    "recommended_action": "BLOCK",  # BLOCK / REVIEW / MONITOR / APPROVE
    "anomaly_details": [...],       # 상세 이상 징후
    "pattern_tags": ["upcoding"]    # 패턴 태그
}

# 배치 패턴 → submit_pattern_analysis
{
    "patterns_found": [...],
    "overall_risk_assessment": "...",
    "priority_actions": [...]
}
```

### 모델 선택 가이드

| 모델 | 속도 | 비용 | 분석 품질 | 추천 용도 |
|------|------|------|-----------|-----------|
| gpt-4o-mini | ⚡ 빠름 | 💰 저렴 | ★★★★ | 실시간 분석, 배치 |
| gpt-4o | ⚡ 보통 | 💰💰 | ★★★★★ | 심층 조사, 패턴 탐지 |
| gpt-4-turbo | 🐌 느림 | 💰💰💰 | ★★★★★ | 고위험 건 정밀 분석 |

## 프로젝트 구조

```
FWAdetection/
├── engine/
│   ├── rules.py              # 룰 기반 검증 엔진 (ICD, NDC, HCC)
│   ├── ai_analyzer.py        # 🆕 OpenAI AI 분석기
│   └── sagemaker_replication.py  # 합성 데이터 + 배치 검증
├── app/
│   └── fwa_dashboard.py      # 🆕 통합 Streamlit 대시보드
├── data/
│   └── sample_claims.csv     # 샘플 청구 데이터
├── tests/
│   └── test_ai_analyzer.py   # 🆕 통합 테스트 (11 tests)
├── requirements.txt
└── README.md
```

## 탐지 시나리오

| 시나리오 | 룰엔진 | AI 분석 | 심각도 |
|----------|--------|---------|--------|
| E10+E11 동시 진단 | ICD 충돌 탐지 | 상호 배타적 진단 확인 | 🔴 CRITICAL |
| 고혈압에 GLP-1 처방 | 적응증 미확인 | Off-label prescribing 판단 | 🔴 CRITICAL |
| E11.9 + HCC18 | HCC Upcoding | 합병증 ICD 부재 확인 | 🔴 CRITICAL |
| 고혈압에 인슐린 | NDC 불일치 | 처방 적합성 평가 | 🟡 WARNING |
| 정상 청구 | PASS | 자동 승인 | 🟢 CLEAN |

## 테스트

```bash
# 전체 테스트 실행
pytest tests/test_ai_analyzer.py -v

# 실제 API 테스트 (API key 필요)
OPENAI_API_KEY=sk-... pytest tests/test_ai_analyzer.py -v
```

## 기술 스택

- **Backend**: Python 3.12+, OpenAI SDK, Pandas
- **Frontend**: Streamlit
- **AI**: OpenAI GPT-4o / GPT-4o-mini (Function Calling)
- **Validation**: Custom Rule Engine (ICD-10, NDC, HCC)
- **Testing**: pytest

## License

MIT License

---

Built by [sechan9999](https://github.com/sechan9999) | CDC Senior Data Scientist
