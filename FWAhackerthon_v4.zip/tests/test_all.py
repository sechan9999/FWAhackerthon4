"""
FWA Detection Intelligence v4.0 — 종합 테스트 스위트
=====================================================
7개 모듈 + 기존 엔진 전체 테스트.

Run:
    pytest tests/test_all.py -v
"""
import pytest
import json
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from engine.rules import RxHCCRuleEngine, ClaimRecord, Severity
from engine.sagemaker_replication import SyntheticClaimGenerator, PandasBatchValidator, SageMakerProcessor
from engine.i18n import t, set_language, get_language, get_all_languages


# ============================================================
# 1. 룰엔진 테스트
# ============================================================
class TestRuleEngine:
    def test_normal_claim_passes(self):
        record = ClaimRecord(claim_id="T1", patient_id="P1", icd_codes=["E11.9"],
                             ndc_codes=["00002-1433-80"], hcc_codes=["HCC19"],
                             provider_id="PRV-1", claim_date="2024-01-01", claim_amount=250.0)
        engine = RxHCCRuleEngine()
        results = engine.validate(record)
        assert not any(r.severity == Severity.CRITICAL for r in results)

    def test_glp1_misuse_detected(self):
        record = ClaimRecord(claim_id="T2", patient_id="P2", icd_codes=["I10"],
                             ndc_codes=["00169-4060-12"], hcc_codes=[],
                             provider_id="PRV-2", claim_date="2024-01-01", claim_amount=1200.0)
        engine = RxHCCRuleEngine()
        results = engine.validate(record)
        assert any(r.severity == Severity.CRITICAL for r in results)

    def test_icd_conflict_detected(self):
        record = ClaimRecord(claim_id="T3", patient_id="P3", icd_codes=["E10.9", "E11.9"],
                             ndc_codes=["00002-1433-80"], hcc_codes=[],
                             provider_id="PRV-3", claim_date="2024-01-01", claim_amount=450.0)
        engine = RxHCCRuleEngine()
        results = engine.validate(record)
        assert any(r.severity == Severity.CRITICAL for r in results)

    def test_hcc_upcoding_detected(self):
        record = ClaimRecord(claim_id="T4", patient_id="P4", icd_codes=["E11.9"],
                             ndc_codes=["00002-1433-80"], hcc_codes=["HCC18"],
                             provider_id="PRV-4", claim_date="2024-01-01", claim_amount=3500.0)
        engine = RxHCCRuleEngine()
        results = engine.validate(record)
        assert any(r.severity == Severity.CRITICAL for r in results)


# ============================================================
# 2. AI Analyzer Fallback 테스트
# ============================================================
class TestAIAnalyzerFallback:
    def setup_method(self):
        try:
            from engine.ai_analyzer import FWAAIAnalyzer
            self.analyzer = FWAAIAnalyzer()  # No API key → fallback mode
            self.available = True
        except ImportError:
            self.available = False

    def test_fallback_normal(self):
        if not self.available:
            pytest.skip("ai_analyzer not importable")
        claim = {"claim_id": "FB-1", "icd_codes": "E11.9", "ndc_codes": "00002-1433-80",
                 "hcc_codes": "HCC19", "provider_id": "PRV-1", "claim_date": "2024-01-01",
                 "patient_id": "P1", "claim_amount": 250.0}
        result = self.analyzer.analyze_claim(claim, [{"severity": "PASS", "rule_id": "R1", "message": "OK"}])
        assert result.risk_level == "CLEAN"
        assert result.recommended_action == "APPROVE"

    def test_fallback_fraud(self):
        if not self.available:
            pytest.skip("ai_analyzer not importable")
        claim = {"claim_id": "FB-2", "icd_codes": "I10", "ndc_codes": "00169-4060-12",
                 "hcc_codes": "", "provider_id": "PRV-2", "claim_date": "2024-01-01",
                 "patient_id": "P2", "claim_amount": 1200.0}
        rule_results = [{"severity": "CRITICAL", "rule_id": "GLP1-001", "message": "GLP-1 misuse"}]
        result = self.analyzer.analyze_claim(claim, rule_results)
        assert result.risk_level == "HIGH"
        assert result.fraud_probability > 0.5

    def test_serialization(self):
        if not self.available:
            pytest.skip("ai_analyzer not importable")
        from engine.ai_analyzer import AIAnalysisResult
        r = AIAnalysisResult(claim_id="S1", risk_level="HIGH", confidence=0.9,
                             fraud_probability=0.85, analysis_summary="Test",
                             medical_reasoning="Test", recommended_action="BLOCK")
        d = r.to_dict()
        assert d["risk_level"] == "HIGH"
        json_str = json.dumps(d, ensure_ascii=False)
        assert "HIGH" in json_str


# ============================================================
# 3. 합성 데이터 & 배치 검증 테스트
# ============================================================
class TestSyntheticData:
    def test_generate_default(self):
        gen = SyntheticClaimGenerator()
        df = gen.generate(100, 0.15)
        assert len(df) == 100
        assert "claim_id" in df.columns
        assert "icd_codes" in df.columns

    def test_batch_validation(self):
        gen = SyntheticClaimGenerator()
        df = gen.generate(50, 0.2)
        validator = PandasBatchValidator()
        validated = validator.validate_dataframe(df)
        assert "is_flagged" in validated.columns
        assert "max_severity" in validated.columns
        assert len(validated) == 50

    def test_summary_stats(self):
        gen = SyntheticClaimGenerator()
        df = gen.generate(100, 0.15)
        validator = PandasBatchValidator()
        validated = validator.validate_dataframe(df)
        summary = validator.get_summary(validated)
        assert "total_claims" in summary
        assert summary["total_claims"] == 100
        assert 0 <= summary["pass_rate"] <= 100


# ============================================================
# 4. LangGraph 파이프라인 테스트
# ============================================================
class TestLangGraphPipeline:
    def test_sequential_pipeline(self):
        from engine.langgraph_pipeline import run_fwa_pipeline
        claim = {"claim_id": "PL-1", "patient_id": "P1", "icd_codes": "E11.9",
                 "ndc_codes": "00002-1433-80", "hcc_codes": "HCC19",
                 "provider_id": "PRV-1", "claim_date": "2024-06-15", "claim_amount": 250.0}
        result = run_fwa_pipeline(claim)
        assert result["stage"] == "complete"
        assert "risk_score" in result
        assert "risk_level" in result
        assert "recommended_action" in result
        assert len(result["logs"]) >= 5  # 5 stages

    def test_pipeline_fraud_detection(self):
        from engine.langgraph_pipeline import run_fwa_pipeline
        claim = {"claim_id": "PL-2", "patient_id": "P2", "icd_codes": "I10",
                 "ndc_codes": "00169-4060-12", "hcc_codes": "",
                 "provider_id": "PRV-2", "claim_date": "2024-07-01", "claim_amount": 1200.0}
        result = run_fwa_pipeline(claim)
        assert result["stage"] == "complete"
        assert result["risk_level"] in ("HIGH", "MEDIUM")
        assert result["should_escalate"] is True

    def test_pipeline_metadata(self):
        from engine.langgraph_pipeline import run_fwa_pipeline
        claim = {"claim_id": "PL-3", "patient_id": "P3", "icd_codes": "E11.9",
                 "ndc_codes": "00002-1433-80", "hcc_codes": "",
                 "provider_id": "PRV-3", "claim_date": "2024-01-01", "claim_amount": 100.0}
        result = run_fwa_pipeline(claim)
        assert "metadata" in result
        assert result["metadata"]["engine"] in ("langgraph", "sequential")
        assert "started_at" in result["metadata"]


# ============================================================
# 5. Provider 네트워크 분석 테스트
# ============================================================
class TestProviderNetwork:
    def _make_test_df(self):
        gen = SyntheticClaimGenerator(seed=42)
        df = gen.generate(200, 0.2)
        validator = PandasBatchValidator()
        return validator.validate_dataframe(df)

    def test_network_analysis(self):
        try:
            from engine.provider_network import ProviderNetworkAnalyzer
        except ImportError:
            pytest.skip("provider_network not importable")

        df = self._make_test_df()
        analyzer = ProviderNetworkAnalyzer(shared_patient_threshold=1)
        result = analyzer.analyze(df)
        assert result.total_providers > 0
        assert isinstance(result.suspicious_providers, list)

    def test_profile_building(self):
        try:
            from engine.provider_network import ProviderNetworkAnalyzer
        except ImportError:
            pytest.skip("provider_network not importable")

        df = self._make_test_df()
        analyzer = ProviderNetworkAnalyzer()
        profiles = analyzer._build_profiles(df)
        assert len(profiles) > 0
        first = list(profiles.values())[0]
        assert first.total_claims > 0

    def test_result_serialization(self):
        try:
            from engine.provider_network import NetworkAnalysisResult
        except ImportError:
            pytest.skip("provider_network not importable")

        result = NetworkAnalysisResult(total_providers=10, total_edges=5)
        d = result.to_dict()
        assert d["total_providers"] == 10
        json.dumps(d)  # Should not raise


# ============================================================
# 6. 시계열 이상 탐지 테스트
# ============================================================
class TestTemporalDetector:
    def _make_test_df(self):
        gen = SyntheticClaimGenerator(seed=42)
        df = gen.generate(500, 0.15)
        validator = PandasBatchValidator()
        return validator.validate_dataframe(df)

    def test_temporal_analysis(self):
        from engine.temporal_detector import TemporalAnomalyDetector
        df = self._make_test_df()
        detector = TemporalAnomalyDetector(z_threshold=2.0)
        result = detector.analyze(df)
        assert isinstance(result.monthly_trends, list)
        assert len(result.monthly_trends) > 0
        assert "summary" in result.to_dict()

    def test_monthly_trends(self):
        from engine.temporal_detector import TemporalAnomalyDetector
        df = self._make_test_df()
        detector = TemporalAnomalyDetector()
        result = detector.analyze(df)
        trends = result.monthly_trends
        assert len(trends) > 0
        assert "claim_count" in trends[0]

    def test_weekly_trends(self):
        from engine.temporal_detector import TemporalAnomalyDetector
        df = self._make_test_df()
        detector = TemporalAnomalyDetector()
        result = detector.analyze(df)
        weekly = result.weekly_trends
        assert len(weekly) > 0

    def test_result_serialization(self):
        from engine.temporal_detector import TemporalAnalysisResult
        result = TemporalAnalysisResult()
        d = result.to_dict()
        json.dumps(d)  # Should not raise


# ============================================================
# 7. 알림 모듈 테스트
# ============================================================
class TestAlerts:
    def test_alert_manager_init(self):
        from engine.alerts import AlertManager
        mgr = AlertManager()
        assert not mgr.slack_configured
        assert not mgr.teams_configured

    def test_alert_manager_configured(self):
        from engine.alerts import AlertManager
        mgr = AlertManager(slack_url="https://hooks.slack.com/test", teams_url="https://teams.webhook/test")
        assert mgr.slack_configured
        assert mgr.teams_configured
        assert mgr.any_configured

    def test_severity_filter(self):
        from engine.alerts import AlertManager
        mgr = AlertManager(min_severity="CRITICAL")
        assert mgr._should_alert("CRITICAL")
        assert not mgr._should_alert("WARNING")
        assert not mgr._should_alert("INFO")

    def test_slack_payload_build(self):
        from engine.alerts import AlertManager
        mgr = AlertManager()
        payload = mgr._build_slack_payload("CLM-001", "HIGH", "BLOCK", 85.0, "Test", "PRV-1", ["upcoding"])
        assert "blocks" in payload
        assert len(payload["blocks"]) > 0

    def test_teams_payload_build(self):
        from engine.alerts import AlertManager
        mgr = AlertManager()
        payload = mgr._build_teams_payload("CLM-001", "HIGH", "BLOCK", 85.0, "Test", "PRV-1", ["upcoding"])
        assert "@type" in payload
        assert payload["@type"] == "MessageCard"


# ============================================================
# 8. 다국어 (i18n) 테스트
# ============================================================
class TestI18n:
    def test_korean_default(self):
        set_language("ko")
        assert get_language() == "ko"
        assert "실시간" in t("nav.realtime_scan")

    def test_english(self):
        set_language("en")
        assert get_language() == "en"
        assert "Real-time" in t("nav.realtime_scan")
        set_language("ko")  # Reset

    def test_missing_key(self):
        result = t("nonexistent.key")
        assert result == "nonexistent.key"

    def test_list_value(self):
        set_language("ko")
        examples = t("chat.examples")
        assert isinstance(examples, list)
        assert len(examples) > 0

    def test_all_languages(self):
        langs = get_all_languages()
        assert "ko" in langs
        assert "en" in langs


# ============================================================
# 9. SageMaker 프로세서 테스트
# ============================================================
class TestSageMakerProcessor:
    def test_local_mode(self):
        processor = SageMakerProcessor()
        assert not processor.is_available  # No role set

    def test_chunked_processing(self):
        import tempfile
        gen = SyntheticClaimGenerator()
        df = gen.generate(100, 0.15)
        with tempfile.NamedTemporaryFile(suffix=".csv", delete=False, mode="w") as f:
            df.to_csv(f, index=False)
            input_path = f.name

        output_path = input_path.replace(".csv", "_out.csv")
        processor = SageMakerProcessor(chunk_size=30)
        result = processor.run_processing_job(input_path, output_path)
        assert result.get("engine") == "local_chunked"
        assert result.get("total_chunks") > 1

        import pandas as pd
        validated = pd.read_csv(output_path)
        assert len(validated) == 100
        assert "is_flagged" in validated.columns

        os.unlink(input_path)
        os.unlink(output_path)


# ============================================================
# 10. 통합 테스트
# ============================================================
class TestIntegration:
    def test_full_pipeline_with_batch(self):
        """생성 → 배치 검증 → 파이프라인 분석"""
        from engine.langgraph_pipeline import run_fwa_pipeline

        gen = SyntheticClaimGenerator()
        df = gen.generate(50, 0.2)
        validator = PandasBatchValidator()
        validated = validator.validate_dataframe(df)

        flagged = validated[validated["is_flagged"]]
        assert len(flagged) > 0

        # 첫 번째 플래그 건 파이프라인 분석
        first = flagged.iloc[0].to_dict()
        result = run_fwa_pipeline(first)
        assert result["stage"] == "complete"
        assert result["risk_score"] > 0

    def test_temporal_on_generated_data(self):
        """생성 데이터로 시계열 분석"""
        from engine.temporal_detector import TemporalAnomalyDetector

        gen = SyntheticClaimGenerator()
        df = gen.generate(300, 0.15)
        validator = PandasBatchValidator()
        validated = validator.validate_dataframe(df)

        detector = TemporalAnomalyDetector()
        result = detector.analyze(validated)
        assert result.to_dict()["summary"]["total_months"] > 0
