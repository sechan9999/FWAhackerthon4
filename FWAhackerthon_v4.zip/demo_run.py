"""
FWA Detection Intelligence v4.0 — Full Functional Demo
========================================================
7개 모듈 전체를 실행하고 결과를 출력합니다.
Streamlit 없이 순수 Python으로 모든 기능을 검증.

Run:
    python demo_run.py
"""
import sys
import os
import json
import time

# 프로젝트 루트를 __file__ 기준으로 자동 탐지
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, PROJECT_ROOT)
os.chdir(PROJECT_ROOT)

from engine.rules import RxHCCRuleEngine, ClaimRecord, Severity
from engine.sagemaker_replication import SyntheticClaimGenerator, PandasBatchValidator, SageMakerProcessor
from engine.ai_analyzer import FWAAIAnalyzer
from engine.langgraph_pipeline import run_fwa_pipeline, LANGGRAPH_AVAILABLE
from engine.provider_network import ProviderNetworkAnalyzer, NETWORKX_AVAILABLE
from engine.temporal_detector import TemporalAnomalyDetector
from engine.alerts import AlertManager
from engine.i18n import t, set_language, get_language, get_all_languages


def banner(title):
    print(f"\n{'='*70}")
    print(f"  {title}")
    print(f"{'='*70}")


def sub(title):
    print(f"\n  ── {title} ──")


# ============================================================
# DEMO 1: 다국어 지원
# ============================================================
def demo_i18n():
    banner("1️⃣  다국어 지원 (i18n)")

    for lang in ["ko", "en"]:
        set_language(lang)
        print(f"\n  [{lang.upper()}]")
        print(f"    Nav:  {t('nav.realtime_scan')}")
        print(f"    Nav:  {t('nav.provider_network')}")
        print(f"    Nav:  {t('nav.temporal')}")
        print(f"    Btn:  {t('common.analyze')}")
        print(f"    Chat: {t('chat.examples')[0]}")

    set_language("ko")
    print(f"\n  ✅ 지원 언어: {get_all_languages()}")


# ============================================================
# DEMO 2: 룰엔진 검증
# ============================================================
def demo_rule_engine():
    banner("2️⃣  룰엔진 검증")
    engine = RxHCCRuleEngine()

    scenarios = [
        ("✅ Normal", {"claim_id": "D-001", "patient_id": "P1", "icd_codes": "E11.9",
                       "ndc_codes": "00002-1433-80", "hcc_codes": "HCC19",
                       "provider_id": "PRV-1", "claim_date": "2024-06-15", "claim_amount": 250}),
        ("🔴 ICD Conflict", {"claim_id": "D-002", "patient_id": "P2", "icd_codes": "E10.9,E11.9",
                              "ndc_codes": "00002-1433-80", "hcc_codes": "",
                              "provider_id": "PRV-2", "claim_date": "2024-06-15", "claim_amount": 450}),
        ("🔴 GLP-1 Misuse", {"claim_id": "D-003", "patient_id": "P3", "icd_codes": "I10",
                              "ndc_codes": "00169-4060-12", "hcc_codes": "",
                              "provider_id": "PRV-3", "claim_date": "2024-07-01", "claim_amount": 1200}),
        ("🔴 HCC Upcoding", {"claim_id": "D-004", "patient_id": "P4", "icd_codes": "E11.9",
                              "ndc_codes": "00002-1433-80", "hcc_codes": "HCC18",
                              "provider_id": "PRV-4", "claim_date": "2024-08-01", "claim_amount": 3500}),
    ]

    for name, data in scenarios:
        record = ClaimRecord.from_dict(data)
        results = engine.validate(record)
        max_sev = max((r.severity.value for r in results),
                      key=lambda s: {"CRITICAL": 4, "WARNING": 3, "INFO": 2, "PASS": 1}.get(s, 0),
                      default="PASS")
        print(f"\n  {name} [{data['claim_id']}]")
        print(f"    ICD: {data['icd_codes']} | NDC: {data['ndc_codes']} | HCC: {data['hcc_codes']}")
        print(f"    → Max Severity: {max_sev}")
        for r in results:
            if r.severity.value in ("CRITICAL", "WARNING"):
                print(f"      🚨 [{r.severity.value}] {r.rule_id}: {r.message}")


# ============================================================
# DEMO 3: LangGraph 파이프라인
# ============================================================
def demo_langgraph_pipeline():
    banner("3️⃣  LangGraph 다단계 파이프라인")
    print(f"  Engine: {'LangGraph' if LANGGRAPH_AVAILABLE else 'Sequential Fallback'}")

    # 정상 케이스
    sub("Normal Claim")
    claim_normal = {"claim_id": "PL-NORMAL", "patient_id": "P1", "icd_codes": "E11.9",
                    "ndc_codes": "00002-1433-80", "hcc_codes": "HCC19",
                    "provider_id": "PRV-1", "claim_date": "2024-06-15", "claim_amount": 250}
    t0 = time.time()
    result = run_fwa_pipeline(claim_normal)
    elapsed = time.time() - t0

    print(f"    Stage: {result['stage']}")
    print(f"    Risk Score: {result['risk_score']}")
    print(f"    Risk Level: {result['risk_level']}")
    print(f"    Action: {result['recommended_action']}")
    print(f"    Engine: {result['metadata']['engine']}")
    print(f"    Time: {elapsed:.2f}s")
    print(f"    Pipeline Log:")
    for log in result["logs"]:
        icon = {"ok": "✅", "error": "❌", "fallback": "⚠️"}.get(log["status"], "ℹ️")
        print(f"      {icon} [{log['stage']}] {log['message']}")

    # 부정 케이스
    sub("Fraud Claim (GLP-1 Misuse)")
    claim_fraud = {"claim_id": "PL-FRAUD", "patient_id": "P2", "icd_codes": "I10",
                   "ndc_codes": "00169-4060-12", "hcc_codes": "",
                   "provider_id": "PRV-2", "claim_date": "2024-07-01", "claim_amount": 1200}
    result = run_fwa_pipeline(claim_fraud)
    print(f"    Risk: {result['risk_level']} (Score: {result['risk_score']})")
    print(f"    Action: {result['recommended_action']}")
    print(f"    Escalate: {result['should_escalate']} — {result['escalation_reason']}")


# ============================================================
# DEMO 4: 합성 데이터 & 배치 검증
# ============================================================
def demo_batch_validation():
    banner("4️⃣  합성 데이터 생성 & 배치 검증")

    gen = SyntheticClaimGenerator(seed=42)
    df = gen.generate(1000, anomaly_rate=0.15)
    print(f"  Generated: {len(df)} claims")
    print(f"  Columns: {list(df.columns)}")
    print(f"  Amount range: ${df['claim_amount'].min():.0f} ~ ${df['claim_amount'].max():.0f}")

    sub("Batch Validation")
    t0 = time.time()
    validator = PandasBatchValidator()
    validated = validator.validate_dataframe(df)
    elapsed = time.time() - t0

    summary = validator.get_summary(validated)
    print(f"  ⏱️  Validation time: {elapsed:.2f}s ({len(df)} claims)")
    print(f"  Total:    {summary['total_claims']:,}")
    print(f"  Flagged:  {summary['flagged_claims']:,}")
    print(f"  Pass Rate: {summary['pass_rate']}%")
    print(f"  Risk Amount: ${summary['total_amount_at_risk']:,.0f}")
    print(f"  Severity: {summary['severity_distribution']}")
    print(f"  Anomalies: {summary['anomaly_distribution']}")

    return validated, summary


# ============================================================
# DEMO 5: SageMaker 청크 배치
# ============================================================
def demo_sagemaker_batch():
    banner("5️⃣  SageMaker 청크 배치 처리")
    import tempfile

    gen = SyntheticClaimGenerator(seed=99)
    df = gen.generate(500, 0.2)

    with tempfile.NamedTemporaryFile(suffix=".csv", delete=False, mode="w") as f:
        df.to_csv(f, index=False)
        input_path = f.name

    output_path = input_path.replace(".csv", "_validated.csv")

    processor = SageMakerProcessor(chunk_size=150)
    print(f"  SageMaker available: {processor.is_available}")
    print(f"  Chunk size: 150 rows")
    print(f"  Input: {len(df)} records")

    progress_log = []
    def cb(cur, tot):
        pct = cur / tot * 100
        progress_log.append(pct)
        if len(progress_log) % 2 == 0 or cur == tot:
            bar = "█" * int(pct // 5) + "░" * (20 - int(pct // 5))
            print(f"\r    [{bar}] {pct:.0f}% ({cur}/{tot})", end="", flush=True)

    t0 = time.time()
    result = processor.run_processing_job(input_path, output_path, progress_callback=cb)
    elapsed = time.time() - t0

    print(f"\n  ✅ Engine: {result.get('engine')}")
    print(f"  Chunks: {result.get('total_chunks')}")
    print(f"  Time: {elapsed:.2f}s")
    print(f"  Flagged: {result.get('flagged_claims')}")

    os.unlink(input_path)
    os.unlink(output_path)


# ============================================================
# DEMO 6: Provider 네트워크 분석
# ============================================================
def demo_provider_network(validated_df):
    banner("6️⃣  Provider 네트워크 분석")
    print(f"  NetworkX available: {NETWORKX_AVAILABLE}")

    analyzer = ProviderNetworkAnalyzer(shared_patient_threshold=2)
    t0 = time.time()
    result = analyzer.analyze(validated_df)
    elapsed = time.time() - t0

    print(f"  ⏱️  Analysis time: {elapsed:.2f}s")
    print(f"  Providers: {result.total_providers}")
    print(f"  Connections: {result.total_edges}")
    print(f"  Avg Degree: {result.avg_degree:.1f}")
    print(f"  Density: {result.density:.4f}")

    sub(f"Suspicious Providers ({len(result.suspicious_providers)})")
    for p in result.suspicious_providers[:5]:
        print(f"    🚨 {p['provider_id']}: score={p['risk_score']}, "
              f"flag_rate={p['flag_rate']:.1%}, flagged={p['flagged_claims']}")
        print(f"       Reason: {p.get('reason', 'N/A')}")

    sub(f"Hub Providers ({len(result.hub_providers)})")
    for h in result.hub_providers[:3]:
        print(f"    🔗 {h['provider_id']}: degree={h['degree']} (avg={h['avg_degree']:.1f})")

    sub(f"Clusters ({len(result.clusters)})")
    for c in result.clusters[:3]:
        print(f"    🔵 Cluster #{c['cluster_id']}: {c['size']} members, "
              f"risk={c['avg_risk_score']:.0f}, level={c['risk_level']}")

    sub(f"Referral Anomalies ({len(result.referral_anomalies)})")
    for r in result.referral_anomalies[:3]:
        print(f"    ⚠️ {r['provider_a']} ↔ {r['provider_b']}: "
              f"shared={r['shared_patients']}, severity={r['severity']}")


# ============================================================
# DEMO 7: 시계열 이상 탐지
# ============================================================
def demo_temporal_anomaly(validated_df):
    banner("7️⃣  시계열 이상 탐지")

    detector = TemporalAnomalyDetector(z_threshold=2.0, ma_window=3)
    t0 = time.time()
    result = detector.analyze(validated_df)
    elapsed = time.time() - t0

    s = result.summary
    print(f"  ⏱️  Analysis time: {elapsed:.2f}s")
    print(f"  Date Range: {s['date_range']}")
    print(f"  Total Months: {s['total_months']}")
    print(f"  Anomalies Found: {s['total_anomalies']}")
    print(f"    🔴 Critical: {s['critical']}")
    print(f"    🟡 Warning: {s['warning']}")
    print(f"    ℹ️  Info: {s['info']}")

    sub("Monthly Trends (sample)")
    for m in result.monthly_trends[:4]:
        flag_rate = m.get("flag_rate", 0)
        flag_str = f", flag_rate={flag_rate:.1%}" if flag_rate else ""
        print(f"    📅 {m['year_month']}: {m['claim_count']} claims, "
              f"MA={m.get('ma_count', 0):.0f}{flag_str}")

    sub("Weekly Distribution")
    for w in result.weekly_trends:
        bar_len = int(w.get("claim_count", 0) / 10)
        bar = "█" * bar_len
        day = w.get("day_name", f"Day{w.get('day_of_week', '?')}")
        print(f"    {day:3s}: {bar} {w.get('claim_count', 0)}")

    sub(f"Detected Anomalies ({len(result.anomalies)})")
    for a in result.anomalies[:8]:
        d = a.to_dict() if hasattr(a, "to_dict") else a
        sev = d.get("severity", "INFO")
        icon = {"CRITICAL": "🔴", "WARNING": "🟡", "INFO": "ℹ️"}.get(sev, "ℹ️")
        print(f"    {icon} [{sev}] {d['anomaly_type']} — {d['period']}")
        print(f"       {d['description']}")

    sub("Provider Temporal (Top 5 High-Risk)")
    for p in result.provider_temporal[:5]:
        print(f"    🏥 {p['provider_id']}: {p['total_claims']} claims, "
              f"flagged={p['flagged_claims']}, rate={p['flag_rate']:.1%}")


# ============================================================
# DEMO 8: Slack/Teams 알림
# ============================================================
def demo_alerts():
    banner("8️⃣  Slack/Teams 알림 시스템")

    mgr = AlertManager()
    print(f"  Slack configured: {mgr.slack_configured}")
    print(f"  Teams configured: {mgr.teams_configured}")

    sub("Severity Filter Test")
    mgr_critical = AlertManager(min_severity="CRITICAL")
    print(f"    CRITICAL only → CRITICAL passes: {mgr_critical._should_alert('CRITICAL')}")
    print(f"    CRITICAL only → WARNING passes: {mgr_critical._should_alert('WARNING')}")

    mgr_warn = AlertManager(min_severity="WARNING")
    print(f"    WARNING+ → CRITICAL passes: {mgr_warn._should_alert('CRITICAL')}")
    print(f"    WARNING+ → WARNING passes: {mgr_warn._should_alert('WARNING')}")
    print(f"    WARNING+ → INFO passes: {mgr_warn._should_alert('INFO')}")

    sub("Slack Payload Sample")
    payload = mgr._build_slack_payload(
        "CLM-DEMO-001", "HIGH", "BLOCK", 87.5,
        "GLP-1 Misuse detected without diabetes diagnosis",
        "PRV-DEMO", ["GLP1_MISUSE", "NDC_MISMATCH"]
    )
    print(f"    Blocks: {len(payload['blocks'])}")
    for block in payload["blocks"]:
        btype = block.get("type", "")
        if btype == "header":
            print(f"    📌 Header: {block['text']['text']}")
        elif btype == "section" and "fields" in block:
            for f in block["fields"]:
                print(f"       {f['text'][:50]}")

    sub("Teams Payload Sample")
    teams_payload = mgr._build_teams_payload(
        "CLM-DEMO-001", "HIGH", "BLOCK", 87.5,
        "GLP-1 Misuse", "PRV-DEMO", ["GLP1_MISUSE"]
    )
    print(f"    Card Type: {teams_payload['@type']}")
    print(f"    Theme: #{teams_payload['themeColor']}")
    facts = teams_payload["sections"][0]["facts"]
    for fact in facts[:4]:
        print(f"       {fact['name']}: {fact['value']}")


# ============================================================
# DEMO 9: AI Analyzer Fallback
# ============================================================
def demo_ai_fallback():
    banner("9️⃣  AI Analyzer (Fallback Mode)")

    analyzer = FWAAIAnalyzer()  # No API key → fallback

    sub("Normal Claim Analysis")
    result = analyzer.analyze_claim(
        {"claim_id": "AI-001", "icd_codes": "E11.9", "ndc_codes": "00002-1433-80",
         "hcc_codes": "HCC19", "provider_id": "PRV-1", "claim_date": "2024-01-01",
         "patient_id": "P1", "claim_amount": 250},
        [{"severity": "PASS", "rule_id": "R1", "message": "OK"}]
    )
    print(f"    Risk: {result.risk_level}")
    print(f"    Fraud Prob: {result.fraud_probability:.0%}")
    print(f"    Action: {result.recommended_action}")
    print(f"    Summary: {result.analysis_summary[:80]}")

    sub("Fraud Claim Analysis")
    result = analyzer.analyze_claim(
        {"claim_id": "AI-002", "icd_codes": "I10", "ndc_codes": "00169-4060-12",
         "hcc_codes": "", "provider_id": "PRV-2", "claim_date": "2024-01-01",
         "patient_id": "P2", "claim_amount": 1200},
        [{"severity": "CRITICAL", "rule_id": "GLP1-001", "message": "GLP-1 without diabetes indication"},
         {"severity": "WARNING", "rule_id": "NDC-001", "message": "NDC mismatch"}]
    )
    print(f"    Risk: {result.risk_level}")
    print(f"    Fraud Prob: {result.fraud_probability:.0%}")
    print(f"    Action: {result.recommended_action}")
    print(f"    Summary: {result.analysis_summary[:80]}")


# ============================================================
# DEMO 10: 통합 파이프라인 E2E
# ============================================================
def demo_integration(validated_df, summary):
    banner("🔟  통합 E2E 테스트")

    flagged = validated_df[validated_df["is_flagged"]]
    print(f"  Flagged claims: {len(flagged)}")

    sub("Pipeline on 5 flagged claims")
    for _, row in flagged.head(5).iterrows():
        claim = row.to_dict()
        result = run_fwa_pipeline(claim)
        cid = claim.get("claim_id", "?")
        print(f"    {cid}: score={result['risk_score']:.1f}, "
              f"level={result['risk_level']}, action={result['recommended_action']}")


# ============================================================
# MAIN
# ============================================================
def main():
    print("╔══════════════════════════════════════════════════════════════════════╗")
    print("║       🛡️  FWA Detection Intelligence v4.0 — Full Demo Run          ║")
    print("║       7개 모듈 전체 실행 + 결과 출력                                ║")
    print("╚══════════════════════════════════════════════════════════════════════╝")

    total_start = time.time()

    demo_i18n()
    demo_rule_engine()
    demo_langgraph_pipeline()
    validated_df, summary = demo_batch_validation()
    demo_sagemaker_batch()
    demo_provider_network(validated_df)
    demo_temporal_anomaly(validated_df)
    demo_alerts()
    demo_ai_fallback()
    demo_integration(validated_df, summary)

    total_elapsed = time.time() - total_start

    banner("🏁 DEMO COMPLETE")
    print(f"  Total execution time: {total_elapsed:.2f}s")
    print(f"  All 7 improvements verified ✅")
    print(f"  Streamlit command: streamlit run app/fwa_dashboard.py")
    print()


if __name__ == "__main__":
    main()
